/* Algorithmus - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;

import java.util.Observable;

import javax.swing.JTextArea;

public abstract class Algorithmus extends Observable implements Runnable {
	protected String[] cCode;
	protected String[] detailedcCode;
	protected CodeView code;
	protected JTextArea vertauscht;
	protected int anzahlSwaps;
	protected JTextArea verglichen;
	protected int anzahlCompares;
	protected JTextArea beschreibung;
	public final boolean low = false;
	public final boolean high = true;
	public boolean levelofdetail = false;
	public int[] array;
	protected Thread algThread;
	public boolean isRunning;
	public boolean isStarted;
	public static boolean EINZELSCHRITT = false;
	public static boolean MOVIE = true;
	public boolean mode = EINZELSCHRITT;
	public long waitingTime = 20L;

	public abstract void run();

	public void runAlgorithm() {
		isRunning = true;
		algThread = new Thread(this);
		algThread.start();
	}

	public void stopAlgorithm() {
		isRunning = false;
		setChanged();
		notifyObservers();
		algThread.stop();
	}

	public void pauseAlgorithm() {
		isRunning = false;
	}

	public void continueAlgorithm() {
		isRunning = true;
	}

	protected void pause() {
		try {
			Thread.sleep(waitingTime * 10L);
		} catch (InterruptedException interruptedexception) {
			/* empty */
		}
	}

	protected void vorStop() {
		isRunning = false;
		while (!isRunning) {
			try {
				Thread.sleep(1L);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
	}

	protected void anhalten() {
		while (!isRunning) {
			try {
				Thread.sleep(1L);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
	}

	protected void singleStepWait() {
		if (mode == EINZELSCHRITT) {
			isRunning = false;
			while (!isRunning) {
				try {
					Thread.sleep(1L);
				} catch (InterruptedException interruptedexception) {
					/* empty */
				}
			}
		}
		while (!isRunning) {
			try {
				Thread.sleep(1L);
			} catch (InterruptedException interruptedexception) {
				/* empty */
			}
		}
	}
}
