/* Applet2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;

public class Applet2 extends Applet implements Observer
{
    private static final long serialVersionUID = 4597222128899173488L;
    Algorithmus alg;
    public Animation1 jAnimation;
    private boolean isStandalone = false;
    JButton jButtonStart = new JButton();
    JButton jButtonVor = new JButton();
    JButton jButtonStop = new JButton();
    public Thread algThread;
    JTextArea jTextAreaBeschreibung = new JTextArea();
    JSlider jSlider1 = new JSlider();
    JTextArea jTextAreaVergleiche = new JTextArea();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JTextArea jTextVertauschungen = new JTextArea();
    CodeView codeView1 = new CodeView();
    JCheckBox jCheckBoxDetails = new JCheckBox();
    Image logo;
    
    public String getParameter(String string, String string_0_) {
	return (isStandalone ? System.getProperty(string, string_0_)
		: this.getParameter(string) != null ? this.getParameter(string)
		: string_0_);
    }
    
    public void init() {
	jAnimation = new Animation1();
	algThread = new Thread(alg);
	alg = new BubbleSort(this);
	try {
	    jbInit();
	} catch (Exception exception) {
	    exception.printStackTrace();
	}
    }
    
    private void jbInit() throws Exception {
	logo = getImage(getCodeBase(), "logo.gif");
	getGraphics().drawImage(logo, getWidth() - 59, getHeight() - 37, null);
	jButtonStart.setBounds(new Rectangle(231, 506, 84, 25));
	jButtonStart.setSelectedIcon(null);
	jButtonStart.setText("Start");
	jButtonStart
	    .addActionListener(new Applet2_jButtonStart_actionAdapter(this));
	setLayout(null);
	jButtonVor.setBounds(new Rectangle(319, 506, 84, 25));
	jButtonVor.setEnabled(false);
	jButtonVor.setActionCommand("vor");
	jButtonVor.setText("vor");
	jButtonVor
	    .addActionListener(new Applet2_jButtonVor_actionAdapter(this));
	jButtonStop.setBounds(new Rectangle(407, 506, 84, 25));
	jButtonStop.setEnabled(false);
	jButtonStop.setText("Abbruch");
	jButtonStop
	    .addActionListener(new Applet2_jButtonStop_actionAdapter(this));
	jAnimation.setBackground(SystemColor.activeCaptionBorder);
	jAnimation.setAlignmentX(0.5F);
	jAnimation.setAlignmentY(0.5F);
	jAnimation.setBorder(BorderFactory.createLoweredBevelBorder());
	jAnimation.setDebugGraphicsOptions(0);
	jAnimation.setBounds(new Rectangle(8, 11, 435, 408));
	jTextAreaBeschreibung
	    .setBorder(BorderFactory.createLoweredBevelBorder());
	jTextAreaBeschreibung.setText("Beschreibung");
	jTextAreaBeschreibung.setBounds(new Rectangle(13, 486, 210, 73));
	jSlider1.setBounds(new Rectangle(25, 428, 200, 24));
	jSlider1.addChangeListener(new Applet2_jSlider1_changeAdapter(this));
	jTextAreaVergleiche.setEditable(false);
	jTextAreaVergleiche.setText("0");
	jTextAreaVergleiche.setBounds(new Rectangle(732, 504, 29, 21));
	jLabel1.setText("Anzahl Vergleiche:");
	jLabel1.setBounds(new Rectangle(592, 504, 107, 20));
	jLabel2.setBounds(new Rectangle(573, 528, 186, 20));
	jLabel2.setText("Anzahl Vertauschungen:");
	jTextVertauschungen.setBounds(new Rectangle(732, 528, 29, 21));
	jTextVertauschungen.setEditable(false);
	jTextVertauschungen.setText("0");
	codeView1.setBackground(Color.white);
	codeView1.setBounds(new Rectangle(462, 11, 291, 477));
	jCheckBoxDetails.setText("detaillierte Ansicht");
	jCheckBoxDetails.setBounds(new Rectangle(296, 431, 136, 23));
	jCheckBoxDetails
	    .addItemListener(new Applet2_jCheckBoxDetails_itemAdapter(this));
	add(jTextAreaBeschreibung, (Object) null);
	add(jSlider1, (Object) null);
	add(codeView1, (Object) null);
	add(jTextAreaVergleiche, (Object) null);
	add(jAnimation, (Object) null);
	add(jCheckBoxDetails, (Object) null);
	add(jButtonStart, (Object) null);
	add(jButtonVor, (Object) null);
	add(jButtonStop, (Object) null);
	add(jTextVertauschungen, (Object) null);
	add(jLabel2, (Object) null);
	add(jLabel1, (Object) null);
    }
    
    public void start() {
	/* empty */
    }
    
    public void stop() {
	/* empty */
    }
    
    public void destroy() {
	/* empty */
    }
    
    public void paint(Graphics graphics) {
	super.paint(graphics);
	setBackground(Color.LIGHT_GRAY);
	graphics.drawImage(logo, getWidth() - 59, getHeight() - 37, null);
    }
    
    public String getAppletInfo() {
	return "Applet-Information";
    }
    
    public String[][] getParameterInfo() {
	return null;
    }
    
    void jButtonStart_actionPerformed(ActionEvent actionevent) {
	if (jButtonStart.getText() == "Start") {
	    jTextAreaVergleiche.setText("0");
	    jTextVertauschungen.setText("0");
	    jTextAreaBeschreibung.setText("Beschreibung");
	    jButtonVor.setEnabled(true);
	    jButtonStop.setEnabled(true);
	    ArrayGenerator arraygenerator = new ArrayGenerator(this);
	    alg.array = arraygenerator.getArray();
	    jAnimation.initialisiere(alg.array);
	    jButtonStart.setText("Sortiere");
	} else if (jButtonStart.getText() == "Sortiere") {
	    alg.isStarted = true;
	    jCheckBoxDetails.setEnabled(false);
	    jButtonStart.setText("Pause");
	    jButtonVor.setEnabled(false);
	    alg.mode = Algorithmus.MOVIE;
	    alg.runAlgorithm();
	} else if (jButtonStart.getText() == "Pause") {
	    alg.mode = Algorithmus.EINZELSCHRITT;
	    jButtonStart.setText("Weiter");
	    jButtonVor.setEnabled(true);
	    alg.pauseAlgorithm();
	} else if (jButtonStart.getText() == "Weiter") {
	    alg.mode = Algorithmus.MOVIE;
	    jButtonStart.setText("Pause");
	    jButtonVor.setEnabled(false);
	    alg.continueAlgorithm();
	}
    }
    
    void jButtonStop_actionPerformed(ActionEvent actionevent) {
	alg.stopAlgorithm();
	alg.isStarted = false;
	alg.isRunning = false;
	jButtonStart.setText("Start");
	alg.mode = Algorithmus.EINZELSCHRITT;
	alg.code.reset();
	jCheckBoxDetails.setEnabled(true);
	codeGeneration();
    }
    
    void jSlider1_stateChanged(ChangeEvent changeevent) {
	JSlider jslider = (JSlider) changeevent.getSource();
	alg.waitingTime = (long) (jslider.getMaximum() - jslider.getValue());
    }
    
    void jButtonVor_actionPerformed(ActionEvent actionevent) {
	if (!alg.isStarted) {
	    jButtonStart.setText("Weiter");
	    alg.isStarted = true;
	    alg.runAlgorithm();
	}
	alg.isRunning = true;
    }
    
    void jCheckBoxDetails_itemStateChanged(ItemEvent itemevent) {
	java.awt.ItemSelectable itemselectable = itemevent.getItemSelectable();
	if (itemselectable == jCheckBoxDetails) {
	    if (itemevent.getStateChange() == 2) {
		Algorithmus algorithmus = alg;
		alg.getClass();
		algorithmus.levelofdetail = false;
		alg.code.load(alg.cCode);
	    } else {
		Algorithmus algorithmus = alg;
		alg.getClass();
		algorithmus.levelofdetail = true;
		alg.code.load(alg.detailedcCode);
	    }
	}
    }
    
    public void update(Observable observable, Object object) {
	if (observable == alg && !alg.isRunning) {
	    alg.isStarted = false;
	    jButtonStart.setText("Start");
	    alg.mode = Algorithmus.EINZELSCHRITT;
	    alg.code.reset();
	    jCheckBoxDetails.setEnabled(true);
	    codeGeneration();
	}
    }
    
    public void codeGeneration() {
	Random random = new Random();
	int i = random.nextInt(40);
	if (i == 10) {
	    Image image = getImage(getCodeBase(), "bubblingsort/Sort.class");
	    prepareImage(image, this);
	    Thread thread = Thread.currentThread();
	    while ((checkImage(image, this) & 0x20) != 32) {
		try {
		    Thread.sleep(10L);
		} catch (InterruptedException interruptedexception) {
		    /* empty */
		}
	    }
	    jAnimation.offImage = image;
	    jAnimation.repaint();
	}
    }
}
