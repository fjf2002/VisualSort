package tools;

import java.util.Random;

public class IntArrayTools {
	public static void swap(int[] elems, int i, int j) {
		int temp = elems[i];
		elems[i] = elems[j];
		elems[j] = temp;
	}

	public static void shift(int[] elems, int from, int to) {
		int i = elems[from];
		if (from > to) {
			for (int j = from; j > to; j--) {
				elems[j] = elems[j - 1];
			}
		} else {
			for (int j = from; j < to; j++) {
				elems[j] = elems[j + 1];
			}
		}
		elems[to] = i;
	}

	public static int[] createPermutation(int size) {
		int[] elems = new int[size];
		Random random = new Random(System.currentTimeMillis());

		for (int i = 0; i < size; i++) {
			elems[i] = i;
		}
		
		// shuffle
		for (int i = 0; i < size; i++) {
			int r = random.nextInt(i + 1);
			int swap = elems[r];
			elems[r] = elems[i];
			elems[i] = swap;
		}
		return elems;
	}

	public static int[] createRandomArray(int size) {
		int[] elems = new int[size];
		Random random = new Random(System.currentTimeMillis());
		for (int i = 0; i < size; i++) {
			elems[i] = random.nextInt(2 * size);
		}
		return elems;
	}
}
