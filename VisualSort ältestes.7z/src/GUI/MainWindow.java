package GUI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

import sortAlgorithms.Algorithms;
import sortAlgorithms.SortAlgorithm;
import sortAlgorithms.opHandlers.AnimationOpHandler;
import GUI.panels.SubPanel;
import controller.Controller;

public class MainWindow extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton stepButton = null;
	private SortPanel sortPanel = null;
	private JPanel panel = null;
	private JButton randomElemsButton = null;
	private JButton playButton = null;
	private JComboBox algorithmComboBox = null;
	private JComboBox problemSizeComboBox = null;
	private JButton restartButton = null;

	private Controller controller;

	private GUICallback finishedCallback = new GUICallback() {
		@Override
		public void callback() {
			playButton.setEnabled(true); // @jve:decl-index=0:
			stepButton.setEnabled(true);
		}
	};

	private JPanel dataPanel = null;
	private JPanel algPanel = null;
	private JLabel problemSizeLabel = null;
	private JLabel algLabel = null;

	/**
	 * This is the default constructor
	 */
	public MainWindow(Controller controller) {
		super();
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(600, 200);
		// this.setSize(800, 600);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getSortPanel(), BorderLayout.CENTER);
			jContentPane.add(getPanel(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes stepButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getStepButton() {
		if (stepButton == null) {
			stepButton = new JButton("Einzelschritt");
			stepButton.addActionListener(this);
		}
		return stepButton;
	}

	/**
	 * This method initializes sortPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private SortPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new SortPanel();
			// sortPanel.setSize(640, 480);
			// sortPanel.setLayout(new GridBagLayout());
		}
		return sortPanel;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			panel.add(getDataPanel(), null);
			panel.add(getAlgPanel(), null);
		}
		return panel;
	}

	/**
	 * This method initializes randomElemsButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getRandomElemsButton() {
		if (randomElemsButton == null) {
			randomElemsButton = new JButton("Zuf�lliges Feld erzeugen");
			randomElemsButton.addActionListener(this);
		}
		return randomElemsButton;
	}

	/**
	 * This method initializes playButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getPlayButton() {
		if (playButton == null) {
			playButton = new JButton("bis Ende ausf�hren");
			playButton.addActionListener(this);
		}
		return playButton;
	}

	/**
	 * This method initializes restartButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getRestartButton() {
		if (restartButton == null) {
			restartButton = new JButton("Neustart");
			restartButton.addActionListener(this);
		}
		return restartButton;
	}

	/**
	 * This method initializes algorithmComboBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getAlgorithmComboBox() {
		if (algorithmComboBox == null) {
			algorithmComboBox = new JComboBox(Algorithms.values());
			algorithmComboBox.addActionListener(this);
			reloadSortAlg();
		}
		return algorithmComboBox;
	}

	private void reloadSortAlg() {
		Algorithms algo = (Algorithms) algorithmComboBox.getSelectedItem();
		SortAlgorithm sortAlg = controller.loadSortAlgorithm(algo);
		sortAlg.setOpHandler(new AnimationOpHandler(sortAlg, sortPanel));
		sortAlg.addCallback(finishedCallback);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if (source == algorithmComboBox) {
			reloadSortAlg();
		} else if (source == restartButton) {
			reloadSortAlg();
			playButton.setEnabled(true);
			stepButton.setEnabled(true);
		} else if (source == playButton) {
			controller.play();
			playButton.setEnabled(false);
			stepButton.setEnabled(false);
		} else if (source == stepButton) {
			controller.step();
		} else if (source == randomElemsButton) {
			int n = (Integer) problemSizeComboBox.getSelectedItem();
			int[] elems = controller.createRandomArray(n);
			sortPanel.setElems(elems);
		}
	}

	/**
	 * This method initializes problemSizeComboBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getProblemSizeComboBox() {
		if (problemSizeComboBox == null) {
			Integer[] sizes = new Integer[] { new Integer(4), new Integer(8),
					new Integer(16), new Integer(32) };
			problemSizeComboBox = new JComboBox(sizes);
		}
		return problemSizeComboBox;
	}

	/**
	 * This method initializes dataPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getDataPanel() {
		if (dataPanel == null) {
			problemSizeLabel = new JLabel();
			problemSizeLabel.setText("Anzahl Elemente:");
			dataPanel = new SubPanel("Daten");
			dataPanel.setLayout(new BoxLayout(dataPanel, BoxLayout.X_AXIS));
			dataPanel.add(problemSizeLabel, null);
			dataPanel.add(getProblemSizeComboBox(), null);
			dataPanel.add(getRandomElemsButton(), null);
		}
		return dataPanel;
	}

	/**
	 * This method initializes algPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getAlgPanel() {
		if (algPanel == null) {
			algLabel = new JLabel();
			algLabel.setText("Algorithmus:");
			algPanel = new SubPanel("Algorithmus");
			algPanel.setLayout(new BoxLayout(algPanel, BoxLayout.X_AXIS));
			algPanel.add(getRestartButton(), null);
			algPanel.add(getStepButton(), null);
			algPanel.add(getPlayButton(), null);
			algPanel.add(algLabel, null);
			algPanel.add(getAlgorithmComboBox(), null);
		}
		return algPanel;
	}

	public static void main(String[] args) {
		try {
			/*
			 * javax.swing.plaf.metal.MetalLookAndFeel
			 * com.sun.java.swing.plaf.motif.MotifLookAndFeel
			 * com.sun.java.swing.plaf.windows.WindowsLookAndFeel
			 * com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel
			 */
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception exc) {
			System.err.println("No such LookAndFeel.");
		}
		new MainWindow(new Controller()).setVisible(true);
	}
}
