package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Item {

	public enum State {
		DEFAULT(new Color(0, 255, 0), new Color(0, 128, 0)), SELECTED(
				new Color(255, 0, 0), new Color(128, 0, 0)), FINISHED(
				new Color(0, 0, 255), new Color(0, 0, 128));

		private Color fillColor;
		private Color drawColor;

		private State(Color fillColor, Color drawColor) {
			this.fillColor = fillColor;
			this.drawColor = drawColor;
		}
	}

	private static int WIDTH = 20;
	private static int HEIGHT_UNIT = 5;
	private static Font font;

	private static final int ARC_DIAM = 3;

	private State state;

	private int size;

	public Item(int size) {
		this.size = size;
		state = State.DEFAULT;
	}

	public static void prepareDraw(int itemWidth, int itemHeightUnit) {
		WIDTH = itemWidth;
		HEIGHT_UNIT = itemHeightUnit;
		font = null;
	}

	public void setState(State state) {
		this.state = state;
	}

	public void draw(Graphics g, int x, int y) {
		if (font == null) {
			int height = g.getFontMetrics().getHeight();
			font = g.getFont();
			font = new Font(font.getFontName(), Font.PLAIN, font.getSize()
					* WIDTH / 2 / height);
		}

		y -= HEIGHT_UNIT * size;
		g.setColor(state.fillColor);
		g.fillRoundRect(x, y, WIDTH, HEIGHT_UNIT * size, ARC_DIAM, ARC_DIAM);
		g.setColor(state.drawColor);
		g.drawRoundRect(x, y, WIDTH, HEIGHT_UNIT * size, ARC_DIAM, ARC_DIAM);
		g.setColor(Color.WHITE);

		g.setFont(font);
		g.drawString(Integer.toString(size), x + 3, y + HEIGHT_UNIT * size - 3);
	}
}
