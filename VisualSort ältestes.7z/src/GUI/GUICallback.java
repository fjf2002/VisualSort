package GUI;

public interface GUICallback {
	public void callback();
}
