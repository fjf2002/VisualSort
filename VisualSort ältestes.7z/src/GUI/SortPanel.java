package GUI;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JPanel;

import tools.Tools;
import GUI.Item.State;

public class SortPanel extends JPanel {
	private static final Color RANGE_COLOR = new Color(41, 115, 184); // RAL_LICHTBLAU

	private static final long serialVersionUID = 1L;

	private Item[] items;

	private Item highlight0 = null;
	private Item highlight1 = null;

	// private int highlightRangeBegin = -1;
	// private int highlightRangeAfterEnd = -1;

	private enum AnimationType {
		ANI_NONE, ANI_SWAP, ANI_SHIFT;
	}

	private AnimationType animationType;

	public class Range {
		public int rangeBegin;
		public int rangeAfterEnd;

		public Range(int rangeBegin, int rangeAfterEnd) {
			this.rangeBegin = rangeBegin;
			this.rangeAfterEnd = rangeAfterEnd;
		}
	}

	private List<Range> ranges;
	private Range highlightRange;

	private int animationI; // i<j
	private int animationJ;
	private float animationProgress;

	public SortPanel() {
		items = new Item[0];
		animationType = AnimationType.ANI_NONE;
		animationI = -1;
		animationJ = -1;
		ranges = new LinkedList<Range>();
	}

	public Item[] getItems() {
		return items;
	}

	public void setElems(int[] elems) {
		items = new Item[elems.length];
		for (int i = 0; i < elems.length; i++) {
			items[i] = new Item(elems[i]);
		}
		highlight0 = null;
		highlight1 = null;
		ranges.clear();
		highlightRange = null;
		repaint();
	}

	public void highlight(int i, int j) {
		highlightOff();
		highlight0 = items[i];
		highlight1 = items[j];
		highlight0.setState(State.SELECTED);
		highlight1.setState(State.SELECTED);
		repaint();
	}

	public void highlightOff() {
		if (highlight0 != null) {
			highlight0.setState(State.DEFAULT);
			highlight0 = null;
		}
		if (highlight1 != null) {
			highlight1.setState(State.DEFAULT);
			highlight1 = null;
		}
		repaint();
	}

	public void highlightRange(int from, int afterTo) {
		highlightRange = new Range(from, afterTo);
		repaint();
	}

	public void addRange(int from, int afterTo) {
		ranges.add(new Range(from, afterTo));
		repaint();
	}

	public void swapAnimation(int i, int j) {
		if (i == j) {
			// items[i].setState(State.SELECTED);
			repaint();
			Tools.sleep(1000);
			// items[i].setState(State.DEFAULT);
			repaint();
			return;
		}
		animationType = AnimationType.ANI_SWAP;
		if (i < j) {
			animationI = i;
			animationJ = j;
		} else {
			animationI = j;
			animationJ = i;
		}
		// items[animationI].setState(State.SELECTED);
		// items[animationJ].setState(State.SELECTED);
		playAnimation();
		// items[animationI].setState(State.DEFAULT);
		// items[animationJ].setState(State.DEFAULT);

		Item swap = items[i];
		items[i] = items[j];
		items[j] = swap;
	}

	public void shiftAnimation(int from, int to) {
		if (from == to) {
			// items[i].setState(State.SELECTED);
			repaint();
			Tools.sleep(1000);
			// items[i].setState(State.DEFAULT);
			repaint();
			return;
		}
		animationType = AnimationType.ANI_SHIFT;
		animationI = from;
		animationJ = to;
		// items[animationI].setState(State.SELECTED);
		playAnimation();
		// items[animationI].setState(State.DEFAULT);

		Item fromItem = items[from];
		for (int i = from; i > to; i--) {
			items[i] = items[i - 1];
		}
		items[to] = fromItem;
	}

	private void playAnimation() {
		final int maxSteps = 20;
		final int delayMs = 50;
		for (int i = 0; i <= maxSteps; i++) {
			animationProgress = (float) i / (float) maxSteps;
			repaint();
			Tools.sleep(delayMs);
		}
		animationType = AnimationType.ANI_NONE;
	}

	public void paint(Graphics g) {
		super.paint(g);
		if (items.length == 0) {
			return;
		}

		final int itemDist = (getWidth() - 10) / items.length;
		Item.prepareDraw(itemDist - 5, (getHeight() - 10) / items.length);

		if (highlightRange != null) {
			// highlight a range
			int begin = highlightRange.rangeBegin * itemDist;
			int end = highlightRange.rangeAfterEnd * itemDist;
			g.setColor(RANGE_COLOR);
			g.fillRect(begin + 3, 0, end - begin, getHeight() - 1);
		}

		g.setColor(new Color(242, 59, 28, 128));
		for (Range r : ranges) {
			int begin = r.rangeBegin * itemDist;
			int end = r.rangeAfterEnd * itemDist;
			g.fillRect(begin + 3, 0, end - begin, getHeight() - 1);
		}

		switch (animationType) {
		case ANI_NONE:
			paintConsecutiveItems(g, 0, items.length - 1, itemDist, 5);
			break;
		case ANI_SWAP: {
			int iX = paintConsecutiveItems(g, 0, animationI - 1, itemDist, 5);
			int offset = iX + itemDist;
			int jX = paintConsecutiveItems(g, animationI + 1, animationJ - 1,
					itemDist, offset);
			offset = jX + itemDist;
			paintConsecutiveItems(g, animationJ + 1, items.length - 1,
					itemDist, offset);

			HalfEllipseParametric ellipse = new HalfEllipseParametric(iX, jX,
					getHeight() - 5, 30);
			Point p = ellipse.evalAt(animationProgress);
			Point q = ellipse.evalAt(-1 + animationProgress);
			items[animationI].draw(g, p.x, p.y);
			items[animationJ].draw(g, q.x, q.y);
		}
			break;
		case ANI_SHIFT: {
			assert animationI > animationJ;
			int i = animationJ;
			int j = animationI;
			int iX = paintConsecutiveItems(g, 0, i - 1, itemDist, 5);
			int jX = iX + (j - i) * itemDist;
			paintConsecutiveItems(g, j + 1, items.length - 1, itemDist, jX
					+ itemDist);

			paintConsecutiveItems(g, i, j - 1, itemDist, iX
					+ (int) (animationProgress * itemDist));

			HalfEllipseParametric ellipse = new HalfEllipseParametric(jX, iX,
					getHeight() - 5, 30);
			Point p = ellipse.evalAt(animationProgress);
			items[j].draw(g, p.x, p.y);
		}
			break;
		}
	}

	private int paintConsecutiveItems(Graphics g, int start, int end,
			int itemDist, int offsetX) {

		int y = this.getHeight() - 5;
		for (int i = start; i <= end; i++) {
			items[i].draw(g, offsetX, y);
			offsetX = offsetX + itemDist;
		}
		return offsetX;
	}

	public void elemFinished(int i) {
		items[i].setState(State.FINISHED);
		repaint();
	}
}
