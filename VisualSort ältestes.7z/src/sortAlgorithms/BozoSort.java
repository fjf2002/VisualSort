package sortAlgorithms;

import java.util.Random;

public class BozoSort extends SortAlgorithm {

	private boolean isSorted() {
		for (int i = 0; i < elems.length - 1; i++) {
			if (elems[i] > elems[i + 1]) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void run() {
		Random random = new Random();

		while (!isSorted()) {
			int i = random.nextInt(elems.length - 1) + 1;
			int j = random.nextInt(i);
			opHandler.swap(i, j);
			stepHandler.stepCompleted();
		}
		algorithmEnd();
	}

}
