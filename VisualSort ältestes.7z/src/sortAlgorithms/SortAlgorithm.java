package sortAlgorithms;

import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

import sortAlgorithms.opHandlers.OpHandler;
import sortAlgorithms.stepHandlers.NoStepHandler;
import sortAlgorithms.stepHandlers.SingleStepHandler;
import sortAlgorithms.stepHandlers.StepHandler;
import GUI.GUICallback;

public class SortAlgorithm extends Thread {
	private List<GUICallback> callbacks;
	protected int[] elems;
	protected OpHandler opHandler;
	protected StepHandler stepHandler;

	public SortAlgorithm() {
		opHandler = new OpHandler(this);
		stepHandler = new NoStepHandler(this);
		callbacks = new LinkedList<GUICallback>();
	}

	public SortAlgorithm(int[] elems) {
		this();
		this.elems = elems;
	}

	public int[] getElems() {
		return elems;
	}

	public void setElems(int[] elems) {
		this.elems = elems;
	}

	public void setOpHandler(OpHandler opHandler) {
		this.opHandler = opHandler;
	}

	public void setSingleStepMode(boolean isSingleStep) {
		if (isSingleStep) {
			stepHandler = new SingleStepHandler(this);
		} else {
			stepHandler = new NoStepHandler(this);
		}
	}

	public boolean isSingleStepMode() {
		return stepHandler instanceof SingleStepHandler;
	}

	protected void algorithmEnd() {
		for (GUICallback callback : callbacks) {
			callback.callback();
		}
		JOptionPane.showMessageDialog(null, "Algorithmus fertig.",
				"Test Titel", JOptionPane.OK_OPTION);
	}

	public void addCallback(GUICallback callback) {
		callbacks.add(callback);
	}
}
