package sortAlgorithms.opHandlers;

import sortAlgorithms.SortAlgorithm;
import GUI.SortPanel;

public class AnimationOpHandler extends OpHandler {

	private SortPanel sortPanel;

	public AnimationOpHandler(SortAlgorithm sortAlg, SortPanel sortPanel) {
		super(sortAlg);
		this.sortPanel = sortPanel;
	}

	@Override
	public void highlight(int i, int j) {
		sortPanel.highlight(i, j);
	}

	@Override
	public void highlightOff() {
		sortPanel.highlightOff();
	}

	@Override
	public void swap(int i, int j) {
		super.swap(i, j);
		sortPanel.swapAnimation(i, j);
	}

	@Override
	public void shift(int from, int to) {
		super.shift(from, to);
		sortPanel.shiftAnimation(from, to);
	}

	@Override
	public void highlightRange(int from, int afterTo) {
		sortPanel.highlightRange(from, afterTo);
	}
}
