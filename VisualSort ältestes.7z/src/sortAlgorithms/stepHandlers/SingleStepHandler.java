package sortAlgorithms.stepHandlers;

import sortAlgorithms.SortAlgorithm;

public class SingleStepHandler extends StepHandler {

	public SingleStepHandler(SortAlgorithm sortAlg) {
		super(sortAlg);
	}

	@Override
	public void stepCompleted() {
		try {
			synchronized (sortAlg) {
				sortAlg.wait();
			}
		} catch (InterruptedException e) {
		}
	}
}
