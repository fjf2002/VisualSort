package sortAlgorithms.stepHandlers;

import sortAlgorithms.SortAlgorithm;

public abstract class StepHandler {
	protected SortAlgorithm sortAlg;

	public StepHandler(SortAlgorithm sortAlg) {
		this.sortAlg = sortAlg;
	}

	public abstract void stepCompleted();
}
