package sortAlgorithms;


public class MergeSort extends SortAlgorithm {

	private int[] merge(int[] links, int[] rechts) {
		int[] list = new int[links.length + rechts.length];
		int li = 0;
		int ri = 0;
		int listi = 0;
		while (listi < list.length) {
			if (ri == rechts.length
					|| (li != links.length && links[li] <= rechts[ri])) {
				
				list[listi] = links[li];
				li++;
			} else {
				list[listi] = rechts[ri];
				ri++;
			}
			listi++;
		}
		return list;
	}

	private int[] mergesort(int[] list) {
		if (list.length <= 1) {
			return list;
		}
		int mitte = list.length / 2;
		int[] links = new int[mitte];
		System.arraycopy(list, 0, links, 0, mitte);
		int[] rechts = new int[list.length - mitte];
		System.arraycopy(list, mitte, rechts, 0, list.length - mitte);

		links = mergesort(links);
		rechts = mergesort(rechts);
		return merge(links, rechts);
	}

	@Override
	public void run() {
		mergesort(elems);
		algorithmEnd();
	}

}
