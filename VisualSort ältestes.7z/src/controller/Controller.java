package controller;

import sortAlgorithms.Algorithms;
import sortAlgorithms.SortAlgorithm;
import tools.IntArrayTools;

public class Controller {

	// private MainWindow mainWindow;

	private int[] elems;

	private SortAlgorithm sortAlg;

	public Controller() {
		elems = IntArrayTools.createPermutation(5);
		sortAlg = Algorithms.values()[0].newAlgorithmInstance();
	}

	public void play() {
		sortAlg.setSingleStepMode(false);
		if (sortAlg.getState() == Thread.State.NEW) {
			sortAlg.start();
		} else if (sortAlg.getState() == Thread.State.WAITING) {
			synchronized (sortAlg) {
				sortAlg.notify();
			}
		}
	}

	public void step() {
		if (!sortAlg.isSingleStepMode()) {
			sortAlg.setSingleStepMode(true);
		}
		if (sortAlg.getState() == Thread.State.NEW) {
			sortAlg.start();
		} else if (sortAlg.getState() == Thread.State.WAITING) {
			synchronized (sortAlg) {
				sortAlg.notify();
			}
		}
	}

	public SortAlgorithm loadSortAlgorithm(Algorithms algorithm) {
		sortAlg = algorithm.newAlgorithmInstance();
		sortAlg.setElems(elems);
		return sortAlg;
	}

	public SortAlgorithm getSortAlgorithm() {
		return sortAlg;
	}

	public int[] createRandomArray(int n) {
		elems = IntArrayTools.createPermutation(n);
		sortAlg.setElems(elems);
		return elems;
	}

}
