package sortAlgorithms;

import gui.Range;

/**
 * This is the implementation of MergeSort.
 * 
 * @author Franz-Josef
 * 
 */
public class MergeSort extends SortAlgorithm {

	private static final String[] SOURCE_CODE = new String[] {
	  "void merge(int links, int rechts) {",
	  "  int laenge = rechts - links + 1;",
	  "  int mitte = (links + rechts) / 2;",
	  "  int[] tempArray = new int[laenge];",
	  "  int l = links;",
	  "  int r = mitte + 1;",
	  "  int t = 0;",
	  "",
	  "  while(t < laenge) {",
	  "    if (r > rechts || (l <= mitte && elems[l] <= elems[r])) {",
	  "      tempArray[t] = elems[l];",
	  "      l = l + 1;",
	  "    } else {",
	  "      tempArray[t] = elems[r];",
	  "      r = r + 1;",
	  "    }",
	  "    t = t + 1;",
	  "  }",
	  "  System.arraycopy(tempArray, 0, elems, links, laenge);",
	  "}",
	  "",
	  "void mergesort(int links, int rechts) {",
	  "  if(links < rechts) {",
	  "    int mitte = (links + rechts) / 2;",
	  "    mergesort(links, mitte);",
	  "    mergesort(mitte + 1, rechts);",
	  "    merge(links, rechts);",
	  "  }",
	  "}"
	};

	@Override
	public String[] getSourceCode() {
		return SOURCE_CODE;
	}

	/*
	private static final String[] SOURCE_CODEx = new String[] {
			"int[] merge(int[] links, int[] rechts) {",
			"  int[] tempList = new int[links.length + rechts.length",
			"  int l = 0;",
			"  int r = 0;",
			"  int t = 0;",
			"  while (t < tempList.length) {",
			"    if (r == rechts.length ||",
			"       (l != links.length && links[l] <= rechts[r])) {",
			"      tempList[t] = links[l];",
			"      l = l + 1;",
			"    } else {",
			"      tempList[t] = rechts[r];",
			"      r = r + 1;",
			"    }",
			"    t = t + 1;",
			"  }",
			"  System.arraycopy(tempList, 0, elems, offset, tempList.length);",
			"  return tempList;",
			"}",
			"",
			"int[] mergesort(int[] elems) {",
			"  if (elems.length <= 1) {",
			"    return elems;",
			"  }",
			"  int mitte = elems.length / 2;",
			"  int[] links = new int[mitte];",
			"  System.arraycopy(elems, 0, links, 0, mitte);",
			"  int[] rechts = new int[elems.length - mitte];",
			"  System.arraycopy(elems, mitte, rechts, 0, elems.length - mitte);",
			"  links = mergesort(links, offset);",
			"  rechts = mergesort(rechts, offset + mitte);",
			"  return merge(links, rechts, offset);", "}" };

	private int[] merge(int[] links, int[] rechts, int offset) {
		int[] tempList = new int[links.length + rechts.length];
		aniHandler.createTempArray(offset, tempList.length, "Hilfs-Feld");
		int li = 0;
		aniHandler.setPointer("li", offset + li);
		int ri = 0;
		aniHandler.setPointer("ri", offset + links.length + ri);
		int tempListi = 0;
		aniHandler.setTempPointer("listi", tempListi);
		while (tempListi < tempList.length) {
			if (ri == rechts.length
					|| (li != links.length && links[li] <= rechts[ri])) {

				tempList[tempListi] = links[li];
				aniHandler.loadItemIntoTempArray(offset + li);
				li++;
				aniHandler.setPointer("li", offset + li);
			} else {
				tempList[tempListi] = rechts[ri];
				aniHandler.loadItemIntoTempArray(offset + links.length + ri);
				ri++;
				aniHandler.setPointer("ri", offset + links.length + ri);
			}
			tempListi++;
			aniHandler.setTempPointer("listi", tempListi);
		}
		// System.arraycopy(tempList, 0, elems, offset, tempList.length);
		aniHandler.integrateTempArray();
		return tempList;
	}

	private int[] mergesortOld(int[] elems, int offset) {
		if (elems.length <= 1) {
			return elems;
		}
		int mitte = elems.length / 2;
		int[] links = new int[mitte];
		System.arraycopy(elems, 0, links, 0, mitte);
		int[] rechts = new int[elems.length - mitte];
		System.arraycopy(elems, mitte, rechts, 0, elems.length - mitte);

		Range leftRange = aniHandler.addRange(offset, offset + mitte);
		stepHandler.stepCompleted();
		links = mergesortOld(links, offset);
		aniHandler.removeRange(leftRange);

		Range rightRange = aniHandler.addRange(offset + mitte, offset
				+ elems.length);
		stepHandler.stepCompleted();
		rechts = mergesortOld(rechts, offset + mitte);
		aniHandler.removeRange(rightRange);

		return merge(links, rechts, offset);
	}
	*/
	
	private void merge(int links, int rechts) {
		// remove mitte pointer set in mergesort: 
		aniHandler.removePointer("mitte");
		// f�r �bersichtlichkeit: links und rechts-pfeile entfernen
		aniHandler.removePointer("links");
		aniHandler.removePointer("rechts");
		setSourceCodeLine(1);
		int laenge = rechts - links + 1;
		setSourceCodeLine(2);
		int mitte = (links + rechts) / 2;
		aniHandler.setPointer("mitte", mitte);
		setSourceCodeLine(3);
		int[] tempArray = new int[laenge];
		aniHandler.createTempArray(links, laenge, "tempArray");
		setSourceCodeLine(4);
		int l = links;
		aniHandler.setPointer("l", l);
		setSourceCodeLine(5);
		int r = mitte + 1;
		aniHandler.setPointer("r", r);
		setSourceCodeLine(6);
		int t = 0;
		aniHandler.setTempPointer("t", t);
		setSourceCodeLine(8);
		
		while(t < laenge) {
			setSourceCodeLine(9);
			if (r > rechts || (l <= mitte && elems[l] <= elems[r])) {
				setSourceCodeLine(10);
				tempArray[t] = elems[l];
				aniHandler.loadItemIntoTempArray(l);
				setSourceCodeLine(11);
				l = l + 1;
				aniHandler.setPointer("l", l);
				setSourceCodeLine(16);
			} else {
				setSourceCodeLine(12);
				setSourceCodeLine(13);
				tempArray[t] = elems[r];
				aniHandler.loadItemIntoTempArray(r);
				setSourceCodeLine(14);
				r = r + 1;
				aniHandler.setPointer("r", r);
				setSourceCodeLine(16);
			}
			t = t + 1;
			aniHandler.setTempPointer("t", t);
			setSourceCodeLine(8);
		}
		setSourceCodeLine(18);
		System.arraycopy(tempArray, 0, elems, links, laenge);
		aniHandler.integrateTempArray();
		aniHandler.removePointer("l");
		aniHandler.removePointer("r");
		aniHandler.removePointer("t");
	}

	private void mergesort(int links, int rechts) {
		aniHandler.setPointer("links", links);
		aniHandler.setPointer("rechts", rechts);
		setSourceCodeLine(22);
		if(links < rechts) {
			setSourceCodeLine(23);
			int mitte = (links + rechts) / 2;
			aniHandler.setPointer("mitte", mitte);
			Range leftRange = aniHandler.addRange(links, mitte+1);
			setSourceCodeLine(24);		
			aniHandler.removePointer("mitte");
			mergesort(links, mitte);
			aniHandler.removeRange(leftRange);
			// restore pointers:
			aniHandler.setPointer("links", links);
			aniHandler.setPointer("mitte", mitte);
			aniHandler.setPointer("rechts", rechts);
			
			aniHandler.setPointer("mitte", mitte);
			Range rightRange = aniHandler.addRange(mitte+1, rechts+1);
			setSourceCodeLine(25);		
			aniHandler.removePointer("mitte");
			mergesort(mitte+1, rechts);
			aniHandler.removeRange(rightRange);
			// restore pointers:
			aniHandler.setPointer("links", links);
			aniHandler.setPointer("mitte", mitte);
			aniHandler.setPointer("rechts", rechts);
	
			setSourceCodeLine(26);		
			merge(links, rechts);
			// restore pointers:
			aniHandler.setPointer("links", links);
			aniHandler.setPointer("mitte", mitte);
			aniHandler.setPointer("rechts", rechts);
	    }
		setSourceCodeLine(27);
	}

	@Override
	public void run() {
		// elems = mergesort(elems, 0);
		mergesort(0, elems.length - 1);
		algorithmEnd();
	}

}
