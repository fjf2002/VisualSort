package GUI;

public interface GUICallback {
	
	public enum State {
		FINISHED, PAUSED;
	}
	
	public void callback(State state);
}
