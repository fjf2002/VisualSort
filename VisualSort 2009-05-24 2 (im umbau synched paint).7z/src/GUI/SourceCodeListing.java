package GUI;

import java.awt.Color;
import java.awt.Font;

import javax.swing.AbstractListModel;
import javax.swing.JList;

import tools.RALColors;

public class SourceCodeListing extends JList {

	private static final long serialVersionUID = 1L;

	public SourceCodeListing() {
		super();
		super.setEnabled(false);
		super.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		super.setForeground(Color.BLACK);
		super.setBackground(Color.WHITE);
		super.setSelectionBackground(RALColors.SCHWEFELGELB);
		super.setSelectionForeground(Color.BLACK);
		super.setPrototypeCellValue("AaBbCc");
	}

	public void loadSourceCode(final String[] sourceCode) {
		super.setModel(new AbstractListModel() {
			private static final long serialVersionUID = 1L;

			public int getSize() {
				return sourceCode.length;
			}

			public Object getElementAt(int i) {
				return sourceCode[i];
			}
		});
	}

	public void setSourceCodeLine(int line) {
		super.setSelectedIndex(line);
	}
}
