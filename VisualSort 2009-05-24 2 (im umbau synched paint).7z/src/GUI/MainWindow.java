package GUI;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.UIManager;

import sortAlgorithms.AlgorithmEnum;
import sortAlgorithms.SortAlgorithm;
import sortAlgorithms.opHandlers.AnimationOpHandler;
import GUI.panels.SubPanel;
import controller.Controller;

public class MainWindow extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JSplitPane jContentPane = null;
	private JButton stepButton = null;
	private SortPanel sortPanel = null;
	private JPanel yPanel = null;
	private JButton playButton = null;
	private JButton restartButton = null;

	private Controller controller;

	private GUICallback finishedCallback = new GUICallback() {
		@Override
		public void callback(GUICallback.State state) {
			boolean isPaused = (state == GUICallback.State.PAUSED);
			restartButton.setEnabled(true);
			playButton.setEnabled(isPaused);
			stepButton.setEnabled(isPaused);
			pauseButton.setEnabled(false);

			if (!isPaused) {
				JOptionPane.showMessageDialog(MainWindow.this,
						"Algorithmus beendet.", "Visual Sort",
						JOptionPane.OK_OPTION);
			}
		}
	};

	private JPanel buttonPanel = null;

	private OptionsDialog optionsDialog;
	private SourceCodeListing jSourceCodeList = null;
	private JButton pauseButton = null;

	/**
	 * This is the default constructor
	 */
	public MainWindow(Controller controller) {
		super();
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(800, 600);
		this.setContentPane(getJContentPane());
		this.setTitle("Visual Sort");
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private Container getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
					getYPanel(), getJSourceCodeList());
			jContentPane.setDividerLocation(0.6d);
			jContentPane.setResizeWeight(0.6d);
		}
		return jContentPane;
	}

	/**
	 * This method initializes stepButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getStepButton() {
		if (stepButton == null) {
			stepButton = new JButton("Einzelschritt");
			stepButton.addActionListener(this);
			stepButton.setEnabled(false);
		}
		return stepButton;
	}

	/**
	 * This method initializes sortPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	public SortPanel getSortPanel() {
		if (sortPanel == null) {
			sortPanel = new SortPanel();
			// sortPanel.setSize(640, 480);
			// sortPanel.setLayout(new GridBagLayout());
		}
		return sortPanel;
	}

	/**
	 * This method initializes yPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getYPanel() {
		if (yPanel == null) {
			yPanel = new JPanel();
			yPanel.setLayout(new BoxLayout(yPanel, BoxLayout.Y_AXIS));
			yPanel.add(getSortPanel(), null);
			yPanel.add(getButtonPanel(), null);
		}
		return yPanel;
	}

	/**
	 * This method initializes playButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getPlayButton() {
		if (playButton == null) {
			playButton = new JButton("bis Ende ausf�hren");
			playButton.addActionListener(this);
			playButton.setEnabled(false);
		}
		return playButton;
	}

	/**
	 * This method initializes restartButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getRestartButton() {
		if (restartButton == null) {
			restartButton = new JButton("Neustart");
			restartButton.addActionListener(this);
		}
		return restartButton;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if (source == restartButton) {
			getOptionsDialog().setVisible(true);
			if (optionsDialog.OKPressed()) {
				AlgorithmEnum algo = optionsDialog.getAlgorithm();
				this.setTitle("Visual Sort - " + algo);
				SortAlgorithm sortAlg = controller.loadSortAlgorithm(algo);
				sortAlg.setOpHandler(new AnimationOpHandler(sortAlg, this));
				sortAlg.addCallback(finishedCallback);

				jSourceCodeList.loadSourceCode(sortAlg.getSourceCode());

				int[] elems = null;

				// fjftemp TODO replace conditional with dynamic binding?
				if (optionsDialog.getArrayType() == ArrayCreationType.PERMUTATION_NUMBERS) {
					elems = controller
							.createRandomPermutationArray(optionsDialog
									.getProblemSize());
				} else if (optionsDialog.getArrayType() == ArrayCreationType.RANDOM_NUMBERS) {
					elems = controller.createRandomArray(optionsDialog
							.getProblemSize());
				}

				sortPanel.setElems(elems);

				playButton.setEnabled(true);
				stepButton.setEnabled(true);
			}
		} else if (source == playButton) {
			controller.play();
			playButton.setEnabled(false);
			stepButton.setEnabled(false);
			restartButton.setEnabled(false);
			pauseButton.setEnabled(true);
		} else if (source == stepButton) {
			controller.step();
		} else if (source == pauseButton) {
			controller.pause();
			pauseButton.setEnabled(false);
		}
	}

	/**
	 * This method initializes buttonPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new SubPanel("Algorithmus - Playback");
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
			buttonPanel.add(getRestartButton(), null);
			buttonPanel.add(getStepButton(), null);
			buttonPanel.add(getPlayButton(), null);
			buttonPanel.add(getPauseButton(), null);
			buttonPanel.add(Box.createHorizontalGlue());
		}
		return buttonPanel;
	}

	private OptionsDialog getOptionsDialog() {
		if (optionsDialog == null) {
			optionsDialog = new OptionsDialog(this);
		}
		return optionsDialog;
	}

	/**
	 * This method initializes jSourceCodeList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getJSourceCodeList() {
		if (jSourceCodeList == null) {
			jSourceCodeList = new SourceCodeListing();
			jSourceCodeList.setPreferredSize(new Dimension(250, getHeight()));
		}
		return jSourceCodeList;
	}

	public void setSourceCodeLine(int line) {
		jSourceCodeList.setSourceCodeLine(line);
	}

	/**
	 * This method initializes jPauseButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getPauseButton() {
		if (pauseButton == null) {
			pauseButton = new JButton("anhalten");
			pauseButton.addActionListener(this);
			pauseButton.setEnabled(false);
		}
		return pauseButton;
	}

	public static void main(String[] args) {
		try {
			/*
			 * javax.swing.plaf.metal.MetalLookAndFeel
			 * com.sun.java.swing.plaf.motif.MotifLookAndFeel
			 * com.sun.java.swing.plaf.windows.WindowsLookAndFeel
			 * com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel
			 */
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception exc) {
			System.err.println("No such LookAndFeel.");
		}
		new MainWindow(new Controller()).setVisible(true);
	}
}
