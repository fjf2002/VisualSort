package GUI;

public enum ArrayCreationType {
	PERMUTATION_NUMBERS("Permutation von Zahlen"), RANDOM_NUMBERS(
			"zuf�llige Zahlen");

	private String name;

	ArrayCreationType(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name;
	}
}
