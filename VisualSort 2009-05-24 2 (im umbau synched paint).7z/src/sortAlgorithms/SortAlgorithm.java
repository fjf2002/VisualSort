package sortAlgorithms;

import java.util.LinkedList;
import java.util.List;

import sortAlgorithms.opHandlers.OpHandler;
import sortAlgorithms.stepHandlers.StepHandler;
import GUI.GUICallback;

public class SortAlgorithm extends Thread {
	private List<GUICallback> callbacks;
	protected int[] elems;
	protected OpHandler opHandler;
	protected StepHandler stepHandler;

	public SortAlgorithm() {
		opHandler = new OpHandler(this);
		stepHandler = new StepHandler(this);
		callbacks = new LinkedList<GUICallback>();
	}

	public SortAlgorithm(int[] elems) {
		this();
		this.elems = elems;
	}

	public int[] getElems() {
		return elems;
	}

	public void setElems(int[] elems) {
		this.elems = elems;
	}

	public void setOpHandler(OpHandler opHandler) {
		this.opHandler = opHandler;
	}

	public void setSingleStepMode(boolean isSingleStep) {
		stepHandler.setSingleStepMode(isSingleStep);
		/*
		 * if (isSingleStep) { stepHandler = new SingleStepHandler(this); } else
		 * { stepHandler = new NoStepHandler(this); }
		 */
	}

	/*
	 * public boolean isSingleStepMode() { return stepHandler instanceof
	 * SingleStepHandler; }
	 */

	public void pause() {
		stepHandler.pause();
	}

	protected void setSourceCodeLine(int line) {
		opHandler.setSourceCodeLine(line);
		stepHandler.stepCompleted();
	}

	protected void algorithmEnd() {
		opHandler.finished();
		callback(GUICallback.State.FINISHED);
	}

	public void callback(GUICallback.State state) {
		for (GUICallback callback : callbacks) {
			callback.callback(state);
		}
	}

	public void addCallback(GUICallback callback) {
		callbacks.add(callback);
	}

	public String[] getSourceCode() {
		return new String[] {};
	}

}
