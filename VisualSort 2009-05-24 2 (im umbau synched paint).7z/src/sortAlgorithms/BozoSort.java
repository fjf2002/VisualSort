package sortAlgorithms;

import java.util.Random;

public class BozoSort extends SortAlgorithm {

	private static final String[] SOURCE_CODE = new String[] {
			"Random random = new Random();", "while (!isSorted()) {",
			"  int i = random.nextInt(elems.length - 1) + 1;",
			"  int j = random.nextInt(i);", 
			"  swap(i, j);",
			"}" };

	@Override
	public String[] getSourceCode() {
		return SOURCE_CODE;
	}
	
	private boolean isSorted() {
		for (int i = 0; i < elems.length - 1; i++) {
			if (elems[i] > elems[i + 1]) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void run() {
		setSourceCodeLine(0);
		Random random = new Random();

		setSourceCodeLine(1);
		while (!isSorted()) {
			setSourceCodeLine(2);
			int i = random.nextInt(elems.length - 1) + 1;
			opHandler.setPointer("i", i);
			setSourceCodeLine(3);
			int j = random.nextInt(i);
			opHandler.setPointer("j", j);
			opHandler.highlight(i, j);
			setSourceCodeLine(4);
			opHandler.swap(i, j);
			opHandler.highlightOff();
		}
		algorithmEnd();
	}
}
