package sortAlgorithms.stepHandlers;

import sortAlgorithms.SortAlgorithm;
import tools.Tools;
import GUI.GUICallback;

public class StepHandler {
	protected SortAlgorithm sortAlg;

	private boolean pauseRequested;

	private boolean singleStepMode;

	public StepHandler(SortAlgorithm sortAlg) {
		this.sortAlg = sortAlg;
		pauseRequested = false;
		singleStepMode = false;
	}

	public void setSingleStepMode(boolean isSingleStep) {
		singleStepMode = isSingleStep;
	}

	public void pause() {
		pauseRequested = true;
		singleStepMode = true;
	}

	public void stepCompleted() {
		if (singleStepMode) {
			try {
				synchronized (sortAlg) {
					if (pauseRequested) {
						sortAlg.callback(GUICallback.State.PAUSED);
						pauseRequested = false;
					}
					sortAlg.wait();
				}
			} catch (InterruptedException e) {
			}
		} else {
			Tools.sleep(500);
		}
	}
}
