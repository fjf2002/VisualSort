package sortAlgorithms.opHandlers;

import sortAlgorithms.SortAlgorithm;
import GUI.MainWindow;
import GUI.Range;
import GUI.SortPanel;

public class AnimationOpHandler extends OpHandler {

	private MainWindow mainWindow;
	private SortPanel sortPanel;

	public AnimationOpHandler(SortAlgorithm sortAlg, MainWindow mainWindow) {
		super(sortAlg);
		this.mainWindow = mainWindow;
		this.sortPanel = mainWindow.getSortPanel();
	}

	@Override
	public void highlight(int i, int j) {
		sortPanel.highlight(i, j);
	}

	@Override
	public void highlightOff() {
		sortPanel.highlightOff();
	}

	@Override
	public void swap(int i, int j) {
		super.swap(i, j);
		sortPanel.swapAnimation(i, j);
	}

	@Override
	public void shift(int from, int to) {
		super.shift(from, to);
		sortPanel.shiftAnimation(from, to);
	}

	@Override
	public void highlightRange(int from, int afterTo) {
		sortPanel.highlightRange(from, afterTo);
	}

	@Override
	public Range addRange(int from, int afterTo) {
		return sortPanel.addRange(from, afterTo);
	}

	@Override
	public void removeRange(Range range) {
		sortPanel.removeRange(range);
	}

	@Override
	public void createTempArray(int offset, int length) {
		sortPanel.createTempArray(offset, length);
	}

	@Override
	public void integrateTempArray() {
		sortPanel.integrateTempArray();
	}

	@Override
	public void loadItemIntoTempArray(int index) {
		sortPanel.loadItemIntoTempArray(index);
	}

	@Override
	public void setPointer(String name, int index) {
		sortPanel.setPointer(name, index);
	}

	@Override
	public void removePointer(String name) {
		sortPanel.setPointer(name, -1);
	}

	@Override
	public void setTempPointer(String name, int index) {
		sortPanel.setTempPointer(name, index);
	}

	@Override
	public void removeTempPointer(String name) {
		sortPanel.setTempPointer(name, -1);
	}

	@Override
	public void setSourceCodeLine(int line) {
		mainWindow.setSourceCodeLine(line);
	}

	@Override
	public void finished() {
		sortPanel.repaint();
	}
}
