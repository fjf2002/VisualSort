package sortAlgorithms;

public class SelectionSort extends SortAlgorithm {

	private static final String[] SOURCE_CODE = new String[] {
			"for (int i = 0; i < elems.length - 1; i++) {",
			"  int minpos = minimumPosition(i);", "  swap(minpos, i)", "}" };

	@Override
	public String[] getSourceCode() {
		return SOURCE_CODE;
	}

	private int minimumPosition(int from) {
		int minpos = from;
		for (int i = from + 1; i < elems.length; i++) {
			if (elems[i] < elems[minpos]) {
				minpos = i;
			}
		}
		return minpos;
	}

	@Override
	public void run() {
		setSourceCodeLine(0);
		for (int i = 0; i < elems.length - 1; i++) {
			opHandler.setPointer("i", i);
			
			setSourceCodeLine(1);
			int minpos = minimumPosition(i);
			opHandler.setPointer("minpos", minpos);

			opHandler.highlight(minpos, i);
			setSourceCodeLine(2);
			opHandler.swap(minpos, i);
			opHandler.highlightOff();
			opHandler.highlightRange(0, i + 1);
			
			opHandler.removePointer("minpos");
			setSourceCodeLine(0);
		}
		opHandler.removePointer("i");
		opHandler.highlightRange(0, elems.length);
		algorithmEnd();
	}

}
