package trash;

public abstract class SortAlgorithm<T extends Comparable<T>> {
	protected T[] elems;
	protected boolean sorted;
	protected boolean bigStepCompleted;

	public SortAlgorithm(T[] elems) {
		this.elems = elems;
		sorted = false;
		bigStepCompleted = false;
	}

	public abstract void smallStep();

	public void bigStep() {
		while (!bigStepCompleted && !sorted) {
			smallStep();
		}
	}

	public void sort() {
		while (!sorted) {
			smallStep();
		}
	}

	protected void swap(int i, int j) {
		T temp = elems[i];
		elems[i] = elems[j];
		elems[j] = temp;
	}

}
