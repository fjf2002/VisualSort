/* ArrayGenerator - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.applet.Applet;
import java.util.Random;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

public class ArrayGenerator
{
    private int maxValue = 100;
    private int[] array;
    
    public ArrayGenerator(Applet applet) {
	Object[] objects
	    = { "vordefinierte Zahlenfolge 1 (8 Zahlen)",
		"vordefinierte Zahlenfolge 2 (50 Zahlen)",
		"absteigend sortierte Zahlenfolge",
		"aufsteigend sortierte Zahlenfolge",
		"zuf\u00e4llige Zahlenfolge", "Zahlenfolge selbst eingeben" };
	String string
	    = ((String)
	       (JOptionPane.showInputDialog
		(applet,
		 "Welche Zahlenfolge willst du sortieren lassen?\n\nDu hast die Wahl unter den vier vordefinierten oder einer zuf\u00e4llig generierten Zahlenfolge!\n(Die vordefinierten Zahlenfolgen sind in allen Applets gleich)\nDu kannst aber auch m\u00fchevoll selbst Zahlen eingeben!\n\n",
		 "Hallo liebeR StudentIn", 3, null, objects, objects[0])));
	if (string == "vordefinierte Zahlenfolge 1 (8 Zahlen)") {
	    array = new int[8];
	    int[] is = { 16, 37, 31, 10, 27, 4, 20, 25 };
	    array = is;
	} else if (string == "vordefinierte Zahlenfolge 2 (50 Zahlen)") {
	    array = new int[50];
	    int[] is = { 34, 16, 35, 15, 46, 47, 28, 25, 16, 10, 30, 40, 9, 46,
			 19, 16, 7, 17, 33, 44, 47, 43, 38, 27, 3, 19, 22, 12,
			 7, 14, 32, 36, 19, 28, 43, 10, 14, 33, 48, 42, 25, 1,
			 40, 37, 3, 1, 22, 9 };
	    array = is;
	} else if (string == "absteigend sortierte Zahlenfolge") {
	    array = new int[getArrayLengthFromUser()];
	    for (int i = 0; i < array.length; i++)
		array[i] = array.length - i;
	} else if (string == "aufsteigend sortierte Zahlenfolge") {
	    array = new int[getArrayLengthFromUser()];
	    for (int i = 0; i < array.length; i++)
		array[i] = i + 1;
	} else if (string == "zuf\u00e4llige Zahlenfolge") {
	    array = new int[getArrayLengthFromUser()];
	    Random random = new Random();
	    int i = 0;
	    while (i < array.length) {
		int i_0_ = random.nextInt(maxValue + 1);
		if (i_0_ != 0) {
		    array[i] = i_0_;
		    i++;
		}
	    }
	} else if (string == "Zahlenfolge selbst eingeben")
	    array = getArrayFromUser();
    }
    
    private int[] getArrayFromUser() {
	String string
	    = (JOptionPane.showInputDialog
	       ("Bitte jetzt die Zahlen deiner Wahl eintippen; durch Kommata getrennt.\n Die Zahlen d\u00fcrfen nicht gr\u00f6\u00dfer als"
		+ Integer.toString(maxValue) + " sein."));
	return parseString(string);
    }
    
    private int[] parseString(String string) {
	Pattern pattern = Pattern.compile("[[,], ]");
	String[] strings = pattern.split(string);
	int[] is = new int[strings.length];
	for (int i = 0; i < strings.length; i++) {
	    try {
		is[i] = Integer.parseInt(strings[i]);
	    } catch (NumberFormatException numberformatexception) {
		is[i] = 1;
	    }
	    if (is[i] > maxValue)
		is[i] = maxValue;
	}
	return is;
    }
    
    public int[] getArray() {
	return array;
    }
    
    private int getArrayLengthFromUser() {
	String string = (JOptionPane.showInputDialog
			 ("Wie viele Zahlen sollen sortiert werden?", "8"));
	int i;
	try {
	    i = Integer.parseInt(string);
	} catch (NumberFormatException numberformatexception) {
	    i = 8;
	}
	return i;
    }
}
