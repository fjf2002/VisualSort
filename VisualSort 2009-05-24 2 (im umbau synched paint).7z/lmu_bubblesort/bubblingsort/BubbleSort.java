/* BubbleSort - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;

public class BubbleSort extends Algorithmus {
	private Animation1 anim;

	public BubbleSort(Applet2 applet2) {
		addObserver(applet2);
		anim = applet2.jAnimation;
		addObserver(applet2);
		code = applet2.codeView1;
		verglichen = applet2.jTextAreaVergleiche;
		vertauscht = applet2.jTextVertauschungen;
		beschreibung = applet2.jTextAreaBeschreibung;
		mode = EINZELSCHRITT;
		detailedcCode = new String[11];
		detailedcCode[0] = "void BubbleSort(){                     ";
		detailedcCode[1] = "  for (int x=0; x < maxIndex; x++)     ";
		detailedcCode[2] = "    for (int y=0; y < maxIndex-x; y++){";
		detailedcCode[3] = "        if (arr[y] > arr[y+1])         ";
		detailedcCode[4] = "          swap(y,y+1);      }";
		detailedcCode[5] = "}                                      ";
		detailedcCode[6] = "void swap(int p1, int p2){             ";
		detailedcCode[7] = "    int temp=arr[p1];                  ";
		detailedcCode[8] = "    arr[p1]=arr[p2];                   ";
		detailedcCode[9] = "    arr[p2]=temp;                      ";
		detailedcCode[10] = "}                                     ";
		cCode = new String[6];
		cCode[0] = "void BubbleSort(){                             ";
		cCode[1] = "  for (int x=0; x < maxIndex; x++)             ";
		cCode[2] = "    for (int y=0; y < maxIndex-x; y++){        ";
		cCode[3] = "        if (arr[y] > arr[y+1])                 ";
		cCode[4] = "          swap(y,y+1);      }        ";
		cCode[5] = "}                                              ";
		code.load(cCode);
	}

	public void run() {
		anzahlSwaps = 0;
		anzahlCompares = 0;
		bubbleSort();
		stopAlgorithm();
		isStarted = false;
		mode = EINZELSCHRITT;
		code.reset();
	}

	private void bubbleSort() {
		code.highlightLine(0);
		pause();
		for (int i = array.length - 1; i > 0; i--) {
			code.highlightLine(1);
			pause();
			for (int j = 0; j < i; j++) {
				code.highlightLine(2);
				pause();
				anim.vergleiche(j, j + 1, array);
				updateBeschreibung(j, j + 1, "Vergleich");
				verglichen.setText(Integer.toString(++anzahlCompares));
				code.highlightLine(3);
				pause();
				singleStepWait();
				if (array[j] > array[j + 1]) {
					updateBeschreibung(j, j + 1, "Vertauschen");
					code.highlightLine(4);
					pause();
					swap(array, j, j + 1);
					vertauscht.setText(Integer.toString(++anzahlSwaps));
					pause();
					singleStepWait();
				}
				anim.unmarkiere(j, j + 1, array);
			}
			anim.markiere(i, array);
		}
		code.highlightLine(5);
		pause();
	}

	private void swap(int[] is, int i, int i_1_) {
		if (levelofdetail) {
			code.highlightLine(6);
			pause();
			code.highlightLine(7);
			pause();
			int i_2_ = is[i];
			code.highlightLine(8);
			pause();
			is[i] = is[i_1_];
			code.highlightLine(9);
			pause();
			is[i_1_] = i_2_;
			anim.tausche(i, i_1_, is);
			code.highlightLine(10);
			pause();
		} else {
			int i_3_ = is[i];
			is[i] = is[i_1_];
			is[i_1_] = i_3_;
			anim.tausche(i, i_1_, is);
			pause();
		}
	}

	private void updateBeschreibung(int i, int i_4_, String string) {
		beschreibung.setText(string + ": \n" + Integer.toString(i + 1)
				+ ".Stelle(Zahl " + Integer.toString(array[i]) + ") mit \n"
				+ Integer.toString(i_4_ + 1) + ".Stelle(Zahl "
				+ Integer.toString(array[i_4_]) + ")");
	}
}
