/* CodeView - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import javax.swing.JPanel;

class CodeView extends JPanel
{
    private static final long serialVersionUID = 2817096383877672803L;
    static final int marginX = 1;
    static final int marginY = 1;
    static final int offsetX = 1;
    static final int offsetY = 1;
    static final int none = -1;
    String[] code;
    Font font = new Font("Monospaced", 0, 12);
    int lineHeight;
    int baseLine;
    int maxWidth = 0;
    int highlightedLine = -1;
    Applet2 applet;
    Color backgroundColor = Color.WHITE;
    
    public CodeView() {
	setBackground(backgroundColor);
    }
    
    public void load(String[] strings) {
	code = strings;
	setFont(font);
	FontMetrics fontmetrics = getFontMetrics(font);
	baseLine = fontmetrics.getAscent();
	lineHeight = baseLine + fontmetrics.getDescent();
	for (int i = 0; i < strings.length; i++)
	    maxWidth = Math.max(maxWidth, fontmetrics.stringWidth(strings[i]));
	maxWidth += 40;
	repaint();
    }
    
    public void reset() {
	if (highlightedLine != -1)
	    colorLine(highlightedLine, Color.WHITE);
	highlightedLine = -1;
	repaint();
    }
    
    private void colorLine(int i, Color color) {
	Graphics graphics = getGraphics();
	int i_0_ = 1 + i * lineHeight;
	graphics.setColor(color);
	graphics.fillRect(0, i_0_, getSize().width - 1, lineHeight);
	graphics.setColor(Color.BLACK);
	graphics.drawString(code[i], 1, i_0_ + baseLine);
    }
    
    public void highlightLine(int i) {
	if (highlightedLine != -1)
	    colorLine(highlightedLine, backgroundColor);
	highlightedLine = i;
	if (highlightedLine != -1)
	    colorLine(highlightedLine, Color.ORANGE);
    }
    
    public void paint(Graphics graphics) {
	graphics.setFont(font);
	graphics.setColor(Color.WHITE);
	graphics.fillRect(0, 0, getSize().width, getSize().height);
	graphics.setColor(Color.BLACK);
	int i = 1 + baseLine;
	int i_1_ = 0;
	while (i_1_ < code.length) {
	    graphics.drawString(code[i_1_], 1, i);
	    i_1_++;
	    i += lineHeight;
	}
	highlightLine(highlightedLine);
    }
}
