package gui;

import gui.panels.SubPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;

import sortAlgorithms.AlgorithmEnum;
import sortAlgorithms.SortAlgorithm;
import tools.IntArrayTools;
import tools.RALColors;
import tools.ThreadTimeMeasurement;

public class RuntimeMeasuringWindow extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel jButtonPanel = null;
	private JButton jClearButton = null;
	private JButton jRunAlgButton = null;
	private Graph graph = null;
	private JList jLegendList = null;
	private JPanel jLegendPanel = null;

	private Map<AlgorithmEnum, Color> algoToColor;
	private JButton jRunAllButton = null;

	/**
	 * This method initializes jButtonPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJButtonPanel() {
		if (jButtonPanel == null) {
			jButtonPanel = new JPanel();
			jButtonPanel
					.setLayout(new BoxLayout(jButtonPanel, BoxLayout.X_AXIS));
			jButtonPanel.add(getJClearButton(), new GridBagConstraints());
			jButtonPanel.add(getJRunAlgButton(), new GridBagConstraints());
			jButtonPanel.add(getJRunAllButton(), null);
		}
		return jButtonPanel;
	}

	/**
	 * This method initializes jClearButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJClearButton() {
		if (jClearButton == null) {
			jClearButton = new JButton("l�schen");
			jClearButton.addActionListener(this);
		}
		return jClearButton;
	}

	/**
	 * This method initializes jRunAlgButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJRunAlgButton() {
		if (jRunAlgButton == null) {
			jRunAlgButton = new JButton("testen");
			jRunAlgButton.addActionListener(this);
		}
		return jRunAlgButton;
	}

	/**
	 * This is the constructor
	 * 
	 * @param algorithmEnum
	 */
	public RuntimeMeasuringWindow() {
		super();
		initialize();

		AlgorithmEnum[] algos = AlgorithmEnum.values();
		algoToColor = new HashMap<AlgorithmEnum, Color>(algos.length);

		for (int i = 0; i < algos.length; i++) {
			algoToColor.put(algos[i], RALColors.COLORS[i]);
		}
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(640, 480);
		this.setContentPane(getJContentPane());
		this.setTitle("Laufzeitmessung Sortieralgorithmen");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJButtonPanel(), BorderLayout.SOUTH);
			jContentPane.add(getGraph(), BorderLayout.CENTER);
			jContentPane.add(getJLegendPanel(), BorderLayout.EAST);
		}
		return jContentPane;
	}

	/**
	 * This method initializes graph
	 * 
	 * @return javax.swing.JPanel
	 */
	private Graph getGraph() {
		if (graph == null) {
			graph = new Graph();
			graph.setLayout(new GridBagLayout());
		}
		return graph;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if (source == jClearButton) {
			graph.clearPoints();
		} else if (source == jRunAlgButton) {
			jRunAlgButton.setText("Einzeltest l�uft...");
			jRunAlgButton.setEnabled(false);
			jRunAllButton.setEnabled(false);
			(new Thread() {
				public void run() {
					RTMOptionsDialog dialog = new RTMOptionsDialog(
							RuntimeMeasuringWindow.this);
					dialog.setVisible(true);
					if (dialog.OKPressed()) {
						int size = dialog.getProblemSize();
						AlgorithmEnum algo = dialog.getAlgorithm();
						SortAlgorithm sortAlg = algo.newAlgorithmInstance();
						sortAlg.setElems(IntArrayTools.createPermutation(size));

						long time = ThreadTimeMeasurement
								.measureExecutionTime(sortAlg);
						graph.addPoint(size, (int) time, algoToColor.get(algo));
					}
					
					// fjf TODO sync
					jRunAlgButton.setText("Einzeltest");
					jRunAlgButton.setEnabled(true);
					jRunAllButton.setEnabled(true);
				}
			}).start();

		} else if (source == jRunAllButton) {
			jRunAllButton.setText("Testreihe l�uft...");
			jRunAllButton.setEnabled(false);
			jRunAlgButton.setEnabled(false);
			(new Thread() {
				public void run() {
					AlgorithmEnum[] algos = AlgorithmEnum.values();
					for (int i = 1; i < algos.length; i++) {
						for (int size = 0; size < 25000; size += 1000) {
							SortAlgorithm sortAlg = algos[i]
									.newAlgorithmInstance();
							sortAlg.setElems(IntArrayTools
									.createPermutation(size));

							long time = ThreadTimeMeasurement
									.measureExecutionTime(sortAlg);
							graph.addPoint(size, (int) time, algoToColor
									.get(algos[i]));
						}
					}
					jRunAllButton.setText("Testreihe");
					jRunAllButton.setEnabled(true);
					jRunAlgButton.setEnabled(true);
				}
			}).start();
		}
	}

	/**
	 * This method initializes jLegendPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJLegendPanel() {
		if (jLegendPanel == null) {
			jLegendPanel = new SubPanel("Legende");
			jLegendPanel.add(getJLegendList());
		}
		return jLegendPanel;
	}

	/**
	 * This method initializes jLegendList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getJLegendList() {
		if (jLegendList == null) {
			jLegendList = new JList();
			jLegendList.setCellRenderer(new ListCellRenderer() {

				@Override
				public Component getListCellRendererComponent(JList list,
						Object value, int index, boolean isSelected,
						boolean cellHasFocus) {

					Component component = (Component) value;
					// component.setBackground(isSelected ? Color.black
					// : Color.white);
					// component.setForeground(isSelected ? Color.white
					// : Color.black);
					return component;

				}
			});

			JLabel[] listEntries = new JLabel[AlgorithmEnum.values().length];

			AlgorithmEnum[] algos = AlgorithmEnum.values();
			for (int i = 0; i < algos.length; i++) {
				JLabel label = new JLabel(algos[i].name());
				label.setOpaque(true);
				label.setBackground(RALColors.COLORS[i]);
				listEntries[i] = label;
			}

			jLegendList.setListData(listEntries);

		}
		return jLegendList;
	}

	/**
	 * This method initializes jRunAllButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJRunAllButton() {
		if (jRunAllButton == null) {
			jRunAllButton = new JButton("Testreihe");
			jRunAllButton.addActionListener(this);
		}
		return jRunAllButton;
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception exc) {
			System.err.println("No such LookAndFeel.");
		}

		(new RuntimeMeasuringWindow()).setVisible(true);
	}
}
