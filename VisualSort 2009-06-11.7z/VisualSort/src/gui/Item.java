package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import tools.RALColors;

public class Item {

	private static final Item NULLITEM = new Item(-1);

	public enum State {
		DEFAULT(RALColors.VERKEHRSGRUEN, RALColors.MOOSGRUEN), SELECTED(
				RALColors.FEUERROT, RALColors.PURPURROT), FINISHED(Color.BLUE,
				Color.BLUE.darker());

		private Color fillColor;
		private Color drawColor;

		private State(Color fillColor, Color drawColor) {
			this.fillColor = fillColor;
			this.drawColor = drawColor;
		}
	}

	private static int WIDTH = 20;
	private static int HEIGHT_UNIT = 5;
	private static Font FONT;

	private static final int ARC_DIAM = 3;

	private State state;

	private int size;

	public Item(int size) {
		this.size = size;
		state = State.DEFAULT;
	}

	public static void prepareDraw(int itemWidth, int itemHeightUnit) {
		WIDTH = itemWidth;
		HEIGHT_UNIT = itemHeightUnit;
		FONT = null;
	}

	public void setState(State state) {
		this.state = state;
	}

	public void draw(Graphics g, int x, int y) {
		if (size < 0) {
			return;
		}

		if (FONT == null) {
			int height = g.getFontMetrics().getHeight();
			FONT = new Font(Font.DIALOG, Font.PLAIN, g.getFont().getSize()
					* WIDTH / height);
		}

		y -= HEIGHT_UNIT * size;
		g.setColor(state.fillColor);
		g.fillRoundRect(x, y, WIDTH, HEIGHT_UNIT * size, ARC_DIAM, ARC_DIAM);
		g.setColor(state.drawColor);
		g.drawRoundRect(x, y, WIDTH, HEIGHT_UNIT * size, ARC_DIAM, ARC_DIAM);
		g.setColor(Color.WHITE);

		g.setFont(FONT);
		g.drawString(Integer.toString(size), x + 3, y + HEIGHT_UNIT * size - 3);
	}

	public String toString() {
		return "Item(" + size + ")";
	}

	public static Item getNullItem() {
		return NULLITEM;
	}
}
