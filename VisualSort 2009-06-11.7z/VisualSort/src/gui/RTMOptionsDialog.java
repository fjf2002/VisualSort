package gui;

import gui.panels.SubPanel;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BoxLayout;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;

import sortAlgorithms.AlgorithmEnum;
import tools.SpringUtilities;

public class RTMOptionsDialog extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JPanel algPanel = null;
	private JComboBox algorithmComboBox = null;
	private JPanel dataPanel = null;
	private JLabel problemSizeLabel = null;
	private JComboBox problemSizeComboBox = null;
	private JButton jOKButton = null;
	private boolean okPressed;

	/**
	 * This is the default constructor
	 */
	public RTMOptionsDialog(Frame owner) {
		super(owner, true);
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		setLocationRelativeTo(getParent());
		this.setSize(300, 200);
		this.setContentPane(getJContentPane());
		this.setTitle("Optionen");
		this.pack();
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane
					.setLayout(new BoxLayout(jContentPane, BoxLayout.Y_AXIS));
			jContentPane.add(getAlgPanel());
			jContentPane.add(getDataPanel());
			jContentPane.add(getJOKButton());

			InputMap inputMap = jContentPane
					.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
			inputMap.put(KeyStroke.getKeyStroke("ESCAPE"), "ESCAPE");

			Action escAction = new AbstractAction() {
				private static final long serialVersionUID = 1L;

				@Override
				public void actionPerformed(ActionEvent e) {
					okPressed = false;
					RTMOptionsDialog.this.dispose();
				}
			};

			jContentPane.getActionMap().put("ESCAPE", escAction);
		}
		return jContentPane;
	}

	/**
	 * This method initializes algPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getAlgPanel() {
		if (algPanel == null) {
			algPanel = new SubPanel("Algorithmus");
			algPanel.setLayout(new BoxLayout(algPanel, BoxLayout.X_AXIS));
			algPanel.add(getAlgorithmComboBox(), null);
		}
		return algPanel;
	}

	/**
	 * This method initializes algorithmComboBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getAlgorithmComboBox() {
		if (algorithmComboBox == null) {
			algorithmComboBox = new JComboBox(AlgorithmEnum.values());
			// algorithmComboBox.addActionListener(this);
		}
		return algorithmComboBox;
	}

	/**
	 * This method initializes problemSizeComboBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getProblemSizeComboBox() {
		if (problemSizeComboBox == null) {
			Integer[] sizes = new Integer[] { new Integer(100),
					new Integer(500), new Integer(1000), new Integer(5000),
					new Integer(10000), new Integer(50000),
					new Integer(100000), new Integer(500000),
					new Integer(1000000), new Integer(5000000) };
			problemSizeComboBox = new JComboBox(sizes);
		}
		return problemSizeComboBox;
	}

	/**
	 * This method initializes dataPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getDataPanel() {
		if (dataPanel == null) {
			problemSizeLabel = new JLabel();
			problemSizeLabel.setText("Anzahl Elemente:");
			dataPanel = new SubPanel("Feld");
			dataPanel.setLayout(new SpringLayout());
			dataPanel.add(problemSizeLabel, null);
			dataPanel.add(getProblemSizeComboBox(), null);
			SpringUtilities.makeCompactGrid(dataPanel, 1, 2, 5, 5, 5, 5);
		}
		return dataPanel;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if (source == jOKButton) {
			okPressed = true;
			this.dispose();
		}
	}

	/**
	 * This method initializes jOKButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJOKButton() {
		if (jOKButton == null) {
			jOKButton = new JButton("OK");
			jOKButton.addActionListener(this);
			jOKButton.setAlignmentX(0.5f);
		}
		return jOKButton;
	}

	@Override
	public void setVisible(boolean b) {
		okPressed = false;
		getRootPane().setDefaultButton(getJOKButton());
		super.setVisible(b);
	}

	public int getProblemSize() {
		return ((Integer) problemSizeComboBox.getSelectedItem()).intValue();
	}

	public AlgorithmEnum getAlgorithm() {
		return ((AlgorithmEnum) algorithmComboBox.getSelectedItem());
	}

	public boolean OKPressed() {
		return okPressed;
	}
}
