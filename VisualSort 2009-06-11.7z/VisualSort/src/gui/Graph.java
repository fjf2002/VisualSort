package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Graph extends JPanel {

	private static final long serialVersionUID = 1L;

	public class CPoint extends Point {
		private static final long serialVersionUID = 1L;

		public Color color;

		public CPoint(int x, int y, Color color) {
			super(x, y);
			this.color = color;
		}
	}

	private ArrayList<CPoint> points;

	private int minX, minY, maxX, maxY;

	public Graph() {
		points = new ArrayList<CPoint>();
		clearPoints();
	}

	public void addPoint(int x, int y, Color color) {
		synchronized (points) {
			minX = Math.min(x, minX);
			minY = Math.min(y, minY);
			maxX = Math.max(x, maxX);
			maxY = Math.max(y, maxY);
			points.add(new CPoint(x, y, color));
		}
		repaint();
	}

	public void clearPoints() {
		synchronized (points) {
			points.clear();
			minX = minY = Integer.MAX_VALUE;
			maxX = maxY = Integer.MIN_VALUE;
		}
		repaint();
	}

	// assert coords.length == 4
	// modifies coords!
	private final void drawLine(Graphics2D g, float[] coords,
			AffineTransform transform) {

		transform.transform(coords, 0, coords, 0, 2);
		g.draw(new Line2D.Float(coords[0], coords[1], coords[2], coords[3]));
	}

	private final void drawString(Graphics2D g, String s, Point2D point,
			AffineTransform transform) {
		Point2D p = transform.transform(point, null);
		g.drawString(s, (float) p.getX(), (float) p.getY());
	}

	private double calcUnit(final int X, float xWidth) {
		float xunit = 30f * xWidth / X;
		double pow10 = Math.pow(10, (int) Math.log10(xunit));
		double fac = xunit / pow10;
		assert fac > 1.0 && fac < 10.0;
		if (fac <= 2d) {
			fac = 2d;
		} else if (fac <= 5d) {
			fac = 5d;
		} else {
			fac = 10d;
		}
		return fac * pow10;
	}

	@Override
	public void paint(Graphics oldG) {
		final int X = getWidth() - 30;
		final int Y = getHeight() - 30;
		if (X <= 0 || Y <= 0) {
			return;
		}
		Graphics2D g = (Graphics2D) oldG;

		float xWidth = Math.max(X, maxX * 1.1f);
		float yWidth = Math.max(Y, maxY * 1.1f);

		AffineTransform transform = new AffineTransform();
		transform.translate(30, Y);
		transform.scale(X / xWidth, -Y / yWidth);

		g.setColor(Color.BLACK);
		g.fillRect(0, 0, getWidth(), getHeight());

		// draw coord system
		g.setColor(Color.WHITE);

		drawLine(g, new float[] { 0, 0, xWidth, 0 }, transform);
		// final double xUnit = Math.pow(10, ((int) Math.log10(xWidth)) - 1);
		// final double yUnit = Math.pow(10, ((int) Math.log10(yWidth)) - 1);

		final double xUnit = calcUnit(X, xWidth);
		final double yUnit = calcUnit(Y, yWidth);

		for (int i = 0; i < xWidth; i += xUnit) {
			Point2D p = transform.transform(new Point(i, 0), null);

			g.draw(new Line2D.Double(p.getX(), p.getY() - 5d, p.getX(), p
					.getY() + 5d));
			g.drawString(Integer.toString(i), (float) p.getX(), (float) p
					.getY() + 20f);
		}

		drawLine(g, new float[] { 0, 0, 0, yWidth }, transform);
		for (int i = 0; i < yWidth; i += yUnit) {
			Point2D p = transform.transform(new Point(0, i), null);

			g.draw(new Line2D.Double(p.getX() - 5d, p.getY(), p.getX() + 5d, p
					.getY()));
			g.drawString(Integer.toString(i), (float) p.getX() - 20f, (float) p
					.getY());
		}

		// draw points
		final int d = 5;
		synchronized (points) {
			for (CPoint p0 : points) {
				g.setColor(p0.color);
				Point2D p = transform.transform(p0, null);
				g.draw(new Line2D.Double(p.getX() - d, p.getY() - d, p.getX()
						+ d, p.getY() + d));
				g.draw(new Line2D.Double(p.getX() + d, p.getY() - d, p.getX()
						- d, p.getY() + d));
			}
		}
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 300);
		// frame.setLayout(new BorderLayout());
		frame.add(new Graph());
		frame.setVisible(true);
	}
}
