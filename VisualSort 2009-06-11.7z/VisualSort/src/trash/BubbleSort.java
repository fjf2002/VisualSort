package trash;


import java.util.Arrays;

public class BubbleSort<T extends Comparable<T>> extends SortAlgorithm<T> {
	private int i;
	private int j;
	private boolean swapped;

	public BubbleSort(T[] elems) {
		super(elems);
		i = 0;
		j = elems.length - 1;
		swapped = false;
	}

	@Override
	public void smallStep() {
		if (sorted) {
			return;
		}
		// assert condition and remove condition?
		if (i < j) {
			if (elems[i].compareTo(elems[i + 1]) > 0) {
				swap(i, i + 1);
				swapped = true;
			}
			i++;
		}

		if (i >= j) {
			// one inner loop ended.
			bigStepCompleted = true;
			if (!swapped) {
				sorted = true;
				return;
			}
			i = 0;
			j--;
			swapped = false;
		} else {
			bigStepCompleted = false;
		}
	}

	public static void main(String[] args) {
		Integer[] array = new Integer[] { 5, 1, 345, 2, 4, 3, 8 };

		BubbleSort<Integer> b = new BubbleSort<Integer>(array);
		while (!b.sorted) {
			b.smallStep();
			System.out.println(Arrays.toString(b.elems) + "\tbigSComp? "
					+ b.bigStepCompleted);
		}
	}

}
