package controller;

import gui.ArrayCreationEnum;
import sortAlgorithms.AlgorithmEnum;
import sortAlgorithms.SortAlgorithm;
import tools.IntArrayTools;

public class Controller {

	// private MainWindow mainWindow;

	private int[] elems;

	private SortAlgorithm sortAlg;

	public Controller() {
		// elems = IntArrayTools.createPermutation(5);
		// sortAlg = AlgorithmEnum.values()[0].newAlgorithmInstance();
	}

	public void play() {
		sortAlg.setSingleStepMode(false);
		resume();
	}

	public void step() {
		// if (!sortAlg.isSingleStepMode()) {
		sortAlg.setSingleStepMode(true);
		// }
		resume();
	}

	private void resume() {
		synchronized (sortAlg) {
			if (sortAlg.getState() == Thread.State.NEW) {
				sortAlg.start();
			} else if (sortAlg.getState() == Thread.State.WAITING) {
				sortAlg.notify();
			}
		}
	}

	public SortAlgorithm loadSortAlgorithm(AlgorithmEnum algorithm) {
		sortAlg = algorithm.newAlgorithmInstance();
		sortAlg.setElems(elems);
		return sortAlg;
	}

	public SortAlgorithm getSortAlgorithm() {
		return sortAlg;
	}

	public int[] createRandomArray(int n) {
		elems = IntArrayTools.createRandomArray(n);
		sortAlg.setElems(elems);
		return elems;
	}

	public int[] createRandomPermutationArray(int n) {
		elems = IntArrayTools.createPermutation(n);
		sortAlg.setElems(elems);
		return elems;
	}

	public void pause() {
		sortAlg.pause();
	}

	/**
	 * Returns null if operation was cancelled by user.
	 * 
	 * @param arrayType
	 * @param size
	 * @return
	 */
	public int[] createArray(ArrayCreationEnum arrayType, int size) {
		int[] elems = arrayType.create(size);
		if (elems != null) {
			this.elems = elems;
			sortAlg.setElems(elems);
		}
		return elems;
	}

}
