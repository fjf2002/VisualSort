package sortAlgorithms.stepHandlers;

public class NoStepHandler implements StepHandler {

	@Override
	public void pause() {
	}

	@Override
	public void setSingleStepMode(boolean isSingleStep) {
	}

	@Override
	public void stepCompleted() {
	}

}
