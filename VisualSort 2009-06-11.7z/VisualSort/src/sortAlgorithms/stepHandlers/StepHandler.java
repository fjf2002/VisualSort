package sortAlgorithms.stepHandlers;

public interface StepHandler {
	public void setSingleStepMode(boolean isSingleStep);

	public void pause();

	public void stepCompleted();
}
