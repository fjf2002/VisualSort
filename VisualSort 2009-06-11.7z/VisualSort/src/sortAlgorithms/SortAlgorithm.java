package sortAlgorithms;

import gui.GUICallback;

import java.util.LinkedList;
import java.util.List;

import sortAlgorithms.opHandlers.AnimationHandler;
import sortAlgorithms.opHandlers.NoAnimationHandler;
import sortAlgorithms.opHandlers.NoSourceCodeView;
import sortAlgorithms.opHandlers.SourceCodeView;
import sortAlgorithms.stepHandlers.NoStepHandler;
import sortAlgorithms.stepHandlers.StepHandler;

public class SortAlgorithm extends Thread {
	private List<GUICallback> callbacks;
	protected int[] elems;
	protected AnimationHandler aniHandler;
	protected StepHandler stepHandler;
	private SourceCodeView sourceCodeHandler;

	public SortAlgorithm() {
		aniHandler = new NoAnimationHandler();
		sourceCodeHandler = new NoSourceCodeView();
		stepHandler = new NoStepHandler();
		callbacks = new LinkedList<GUICallback>();
	}

	public SortAlgorithm(int[] elems) {
		this();
		this.elems = elems;
	}

	protected void swap(int i, int j) {
		int temp = elems[i];
		elems[i] = elems[j];
		elems[j] = temp;
	}

	public int[] getElems() {
		return elems;
	}

	public void setElems(int[] elems) {
		this.elems = elems;
	}

	public void setAnimationHandler(AnimationHandler aniHandler) {
		this.aniHandler = aniHandler;
	}

	public void setSourceCodeHandler(SourceCodeView sourceCodeHandler) {
		this.sourceCodeHandler = sourceCodeHandler;
	}

	public void setSetStepHandler(StepHandler stepHandler) {
		this.stepHandler = stepHandler;
	}

	public void setSingleStepMode(boolean isSingleStep) {
		stepHandler.setSingleStepMode(isSingleStep);
		/*
		 * if (isSingleStep) { stepHandler = new SingleStepHandler(this); } else
		 * { stepHandler = new NoStepHandler(this); }
		 */
	}

	/*
	 * public boolean isSingleStepMode() { return stepHandler instanceof
	 * SingleStepHandler; }
	 */

	public void pause() {
		stepHandler.pause();
	}

	protected void setSourceCodeLine(int line) {
		sourceCodeHandler.setSourceCodeLine(line);
		stepHandler.stepCompleted();
	}

	protected void algorithmEnd() {
		aniHandler.finished();
		callback(GUICallback.State.FINISHED);
	}

	public void callback(GUICallback.State state) {
		for (GUICallback callback : callbacks) {
			callback.callback(state);
		}
	}

	public void addCallback(GUICallback callback) {
		callbacks.add(callback);
	}

	public String[] getSourceCode() {
		return new String[] {};
	}

}
