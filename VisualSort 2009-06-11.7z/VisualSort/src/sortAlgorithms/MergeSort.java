package sortAlgorithms;

import gui.Range;

public class MergeSort extends SortAlgorithm {

	private int[] merge(int[] links, int[] rechts, int offset) {
		int[] tempList = new int[links.length + rechts.length];
		aniHandler.createTempArray(offset, tempList.length);
		int li = 0;
		aniHandler.setPointer("li", offset + li);
		int ri = 0;
		aniHandler.setPointer("ri", offset + links.length + ri);
		int tempListi = 0;
		aniHandler.setTempPointer("listi", tempListi);
		while (tempListi < tempList.length) {
			if (ri == rechts.length
					|| (li != links.length && links[li] <= rechts[ri])) {

				tempList[tempListi] = links[li];
				aniHandler.loadItemIntoTempArray(offset + li);
				li++;
				aniHandler.setPointer("li", offset + li);
			} else {
				tempList[tempListi] = rechts[ri];
				aniHandler.loadItemIntoTempArray(offset + links.length + ri);
				ri++;
				aniHandler.setPointer("ri", offset + links.length + ri);
			}
			tempListi++;
			aniHandler.setTempPointer("listi", tempListi);
		}
		System.arraycopy(tempList, 0, elems, offset, tempList.length);
		aniHandler.integrateTempArray();
		return tempList;
	}

	private int[] mergesort(int[] list, int offset) {
		if (list.length <= 1) {
			return list;
		}
		int mitte = list.length / 2;
		int[] links = new int[mitte];
		System.arraycopy(list, 0, links, 0, mitte);
		int[] rechts = new int[list.length - mitte];
		System.arraycopy(list, mitte, rechts, 0, list.length - mitte);

		Range leftRange = aniHandler.addRange(offset, offset + mitte);
		stepHandler.stepCompleted();
		links = mergesort(links, offset);
		aniHandler.removeRange(leftRange);

		Range rightRange = aniHandler.addRange(offset + mitte, offset
				+ list.length);
		stepHandler.stepCompleted();
		rechts = mergesort(rechts, offset + mitte);
		aniHandler.removeRange(rightRange);

		return merge(links, rechts, offset);
	}

	@Override
	public void run() {
		mergesort(elems, 0);
		algorithmEnd();
	}

}
