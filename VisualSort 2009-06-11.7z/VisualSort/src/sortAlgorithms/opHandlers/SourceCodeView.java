package sortAlgorithms.opHandlers;

public interface SourceCodeView {

	void loadSourceCode(String[] sourceCode);

	void setSourceCodeLine(int line);

}
