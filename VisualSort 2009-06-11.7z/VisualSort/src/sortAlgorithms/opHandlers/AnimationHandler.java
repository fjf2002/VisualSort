package sortAlgorithms.opHandlers;

import gui.Range;

public interface AnimationHandler {

	public void highlight(int i, int j);

	public void highlightOff();

	public void swap(int i, int j);

	// {
	// IntArrayTools.swap(sortAlg.getElems(), i, j);
	// }

	public void shift(int from, int to);

	public void highlightRange(int from, int afterTo);

	public Range addRange(int from, int afterTo);

	public void removeRange(Range leftRange);

	public void createTempArray(int offset, int length);

	public void integrateTempArray();

	public void loadItemIntoTempArray(int index);

	public void setPointer(String string, int index);

	public void removePointer(String string);

	public void setTempPointer(String string, int index);

	public void removeTempPointer(String string);

	public void finished();

	void loadItemFromTempArray(int tempArrayIndex, int arrayIndex);

	void moveAnimation(int from, int to);
}
