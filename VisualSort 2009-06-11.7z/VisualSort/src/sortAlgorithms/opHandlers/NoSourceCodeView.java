package sortAlgorithms.opHandlers;

public class NoSourceCodeView implements SourceCodeView {

	@Override
	public void loadSourceCode(String[] sourceCode) {
	}

	@Override
	public void setSourceCodeLine(int line) {
	}

}
