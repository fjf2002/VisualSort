/* Animation1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JPanel;

public class Animation1 extends JPanel
{
    private static final long serialVersionUID = -8657368772585703168L;
    private int horScaling = 20;
    private int vertScaling = 40;
    private int breite;
    private int hoehe;
    private boolean schreibeZahlen = true;
    Dimension offDimension;
    public Image offImage;
    Graphics offGraphics;
    Graphics g;
    
    public Animation1() {
	try {
	    jbInit();
	} catch (Exception exception) {
	    exception.printStackTrace();
	}
    }
    
    public void initialisiere(int[] is) {
	g = getGraphics();
	breite = getSize().width - 10;
	hoehe = getSize().height - 10;
	horScaling = breite / is.length;
	vertScaling = hoehe / findMax(is);
	if (is.length > 18)
	    schreibeZahlen = false;
	else
	    schreibeZahlen = true;
	offImage = createImage(breite, hoehe);
	offGraphics = offImage.getGraphics();
	offGraphics.setColor(getBackground());
	offGraphics.fillRect(0, 0, breite, hoehe);
	offGraphics.setColor(Color.GREEN);
	if (is != null) {
	    int i = is.length - 1;
	    for (int i_0_ = 0; i_0_ <= i; i_0_++) {
		int i_1_ = 5 + horScaling * i_0_;
		int i_2_ = hoehe - vertScaling * is[i_0_];
		offGraphics.fillRect(i_1_, i_2_, horScaling - 1,
				     vertScaling * is[i_0_]);
		drawNumber(is, i_0_);
	    }
	}
	repaint();
    }
    
    public void tausche(int i, int i_3_, int[] is) {
	offGraphics.setColor(getBackground());
	offGraphics.fillRect(5 + horScaling * i, 0, horScaling - 1, hoehe);
	offGraphics.setColor(Color.RED);
	offGraphics.fillRect(5 + horScaling * i, hoehe - vertScaling * is[i],
			     horScaling - 1, vertScaling * is[i]);
	drawNumber(is, i);
	offGraphics.setColor(getBackground());
	offGraphics.fillRect(5 + horScaling * i_3_, 0, horScaling - 1, hoehe);
	offGraphics.setColor(Color.MAGENTA);
	offGraphics.fillRect(5 + horScaling * i_3_,
			     hoehe - vertScaling * is[i_3_], horScaling - 1,
			     vertScaling * is[i_3_]);
	drawNumber(is, i_3_);
	repaint();
    }
    
    public void vergleiche(int i, int i_4_, int[] is) {
	offGraphics.setColor(getBackground());
	offGraphics.fillRect(5 + horScaling * i, 0, horScaling - 1, hoehe);
	offGraphics.fillRect(5 + horScaling * i_4_, 0, horScaling - 1, hoehe);
	int i_5_ = i;
	int i_6_ = i_4_;
	if (is[i] < is[i_4_]) {
	    i_5_ = i_4_;
	    i_6_ = i;
	}
	offGraphics.setColor(Color.RED);
	offGraphics.fillRect(5 + horScaling * i_6_,
			     hoehe - vertScaling * is[i_6_], horScaling - 1,
			     vertScaling * is[i_6_]);
	drawNumber(is, i_6_);
	offGraphics.setColor(Color.MAGENTA);
	if (is[i] == is[i_4_])
	    offGraphics.setColor(Color.RED);
	offGraphics.fillRect(5 + horScaling * i_5_,
			     hoehe - vertScaling * is[i_5_], horScaling - 1,
			     vertScaling * is[i_5_]);
	drawNumber(is, i_5_);
	repaint();
    }
    
    public void unmarkiere(int i, int i_7_, int[] is) {
	offGraphics.setColor(Color.GREEN);
	offGraphics.fillRect(5 + horScaling * i, hoehe - vertScaling * is[i],
			     horScaling - 1, vertScaling * is[i]);
	offGraphics.fillRect(5 + horScaling * i_7_,
			     hoehe - vertScaling * is[i_7_], horScaling - 1,
			     vertScaling * is[i_7_]);
	drawNumber(is, i);
	drawNumber(is, i_7_);
	repaint();
    }
    
    public void markiere(int i, int[] is) {
	offGraphics.setColor(Color.BLUE);
	offGraphics.fillRect(5 + horScaling * i, hoehe - vertScaling * is[i],
			     horScaling - 1, vertScaling * is[i]);
	drawNumber(is, i);
	repaint();
    }
    
    public void paint(Graphics graphics) {
	super.paint(graphics);
	if (offImage != null)
	    graphics.drawImage(offImage, 5, 5, null);
    }
    
    private void drawNumber(int[] is, int i) {
	if (schreibeZahlen) {
	    Font font = offGraphics.getFont();
	    Color color = offGraphics.getColor();
	    offGraphics.setColor(Color.BLACK);
	    Font font_8_ = new Font("Monospaced", 0, 18);
	    offGraphics.setFont(font_8_);
	    int i_9_ = hoehe - 1;
	    int i_10_ = 5 + horScaling * i;
	    offGraphics.drawString(Integer.toString(is[i]), i_10_, i_9_);
	    offGraphics.setColor(color);
	    offGraphics.setFont(font);
	}
    }
    
    private int findMax(int[] is) {
	int i = 0;
	for (int i_11_ = 0; i_11_ < is.length; i_11_++) {
	    if (is[i_11_] > i)
		i = is[i_11_];
	}
	return i;
    }
    
    private void jbInit() throws Exception {
	/* empty */
    }
}
