/* Applet2_jButtonVor_actionAdapter - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Applet2_jButtonVor_actionAdapter implements ActionListener
{
    Applet2 adaptee;
    
    Applet2_jButtonVor_actionAdapter(Applet2 applet2) {
	adaptee = applet2;
    }
    
    public void actionPerformed(ActionEvent actionevent) {
	adaptee.jButtonVor_actionPerformed(actionevent);
    }
}
