package sortAlgorithms;

public class SelectionSort extends SortAlgorithm {

	private int minimumPosition(int from) {
		int minpos = from;
		for (int i = from + 1; i < elems.length; i++) {
			if (elems[i] < elems[minpos]) {
				minpos = i;
			}
		}
		return minpos;
	}

	@Override
	public void run() {
		for (int i = 0; i < elems.length - 1; i++) {
			int minpos = minimumPosition(i);
			opHandler.setPointer("min", minpos);
			opHandler.setPointer("i", i);
			opHandler.highlight(minpos, i);
			stepHandler.stepCompleted();
			opHandler.swap(minpos, i);
			opHandler.highlightOff();
			opHandler.highlightRange(0, i + 1);
			stepHandler.stepCompleted();
		}
		opHandler.highlightRange(0, elems.length);
		algorithmEnd();
	}

}
