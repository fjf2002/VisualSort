/*package sortAlgorithms.stepHandlers;

import sortAlgorithms.SortAlgorithm;

public class NoStepHandler extends StepHandler {

	public NoStepHandler(SortAlgorithm sortAlg) {
		super(sortAlg);
	}

	@Override
	public void stepCompleted() {
		super.stepCompleted();
	}
}
*/