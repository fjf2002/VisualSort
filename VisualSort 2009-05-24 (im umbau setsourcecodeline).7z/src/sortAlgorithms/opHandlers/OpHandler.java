package sortAlgorithms.opHandlers;

import sortAlgorithms.SortAlgorithm;
import tools.IntArrayTools;
import GUI.Range;

public class OpHandler {
	protected SortAlgorithm sortAlg;

	public OpHandler(SortAlgorithm sortAlg) {
		this.sortAlg = sortAlg;
	}

	public void highlight(int i, int j) {
	}

	public void highlightOff() {
	}

	public void swap(int i, int j) {
		IntArrayTools.swap(sortAlg.getElems(), i, j);
	}

	public void shift(int from, int to) {
		// IntArrayTools.shift(sortAlg.getElems(), from, to);
	}

	public void highlightRange(int from, int afterTo) {
	}

	public Range addRange(int from, int afterTo) {
		return null;
	}

	public void removeRange(Range leftRange) {
	}

	public void createTempArray(int offset, int length) {
	}

	public void integrateTempArray() {
	}
	
	public void loadItemIntoTempArray(int index) {
	}

	public void setPointer(String string, int i) {
	}

	public void setTempPointer(String string, int listi) {
	}
	
	public void setSourceCodeLine(int line) {		
	}

	public void finished() {
	}
}
