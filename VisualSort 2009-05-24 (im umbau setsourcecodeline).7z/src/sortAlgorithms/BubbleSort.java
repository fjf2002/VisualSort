package sortAlgorithms;

import tools.Tools;

public class BubbleSort extends SortAlgorithm {

	private static final String[] SOURCE_CODE = new String[] {
		"for (int i = 0; i < elems.length - 1; i++) {",
		"  for (int j = 0; j < elems.length - 1 - i; j++) {",
		"    if (elems[j] > elems[j + 1]) {",
		"      swap(j, j+1);",
		"    }",
		"  }",
		"}"
	};
	
	@Override
	public String[] getSourceCode() {
		return SOURCE_CODE;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < elems.length - 1; i++) {
			opHandler.setPointer("i", i);
			for (int j = 0; j < elems.length - 1 - i; j++) {
				opHandler.setPointer("j", j);
				opHandler.highlight(j, j + 1);
				stepHandler.stepCompleted();
				if (elems[j] > elems[j + 1]) {
					opHandler.swap(j, j + 1);
					opHandler.highlightOff();
					stepHandler.stepCompleted();
				} else {
					Tools.sleep(1000);
				}
			}
			opHandler.highlightOff();
			opHandler.highlightRange(elems.length - 1 - i, elems.length);
		}
		opHandler.highlightRange(0, elems.length);
		algorithmEnd();
	}

}
