package sortAlgorithms;

import GUI.Range;

public class MergeSort extends SortAlgorithm {

	private int[] merge(int[] links, int[] rechts, int offset) {
		int[] tempList = new int[links.length + rechts.length];
		opHandler.createTempArray(offset, tempList.length);
		int li = 0;
		opHandler.setPointer("li", offset + li);
		int ri = 0;
		opHandler.setPointer("ri", offset + links.length + ri);
		int tempListi = 0;
		opHandler.setTempPointer("listi", tempListi);
		while (tempListi < tempList.length) {
			if (ri == rechts.length
					|| (li != links.length && links[li] <= rechts[ri])) {

				tempList[tempListi] = links[li];
				opHandler.loadItemIntoTempArray(offset + li);
				li++;
				opHandler.setPointer("li", offset + li);
			} else {
				tempList[tempListi] = rechts[ri];
				opHandler.loadItemIntoTempArray(offset + links.length + ri);
				ri++;
				opHandler.setPointer("ri", offset + links.length + ri);
			}
			tempListi++;
			opHandler.setTempPointer("listi", tempListi);
		}
		System.arraycopy(tempList, 0, elems, offset, tempList.length);
		opHandler.integrateTempArray();
		return tempList;
	}

	private int[] mergesort(int[] list, int offset) {
		if (list.length <= 1) {
			return list;
		}
		int mitte = list.length / 2;
		int[] links = new int[mitte];
		System.arraycopy(list, 0, links, 0, mitte);
		int[] rechts = new int[list.length - mitte];
		System.arraycopy(list, mitte, rechts, 0, list.length - mitte);

		Range leftRange = opHandler.addRange(offset, offset + mitte);
		stepHandler.stepCompleted();
		links = mergesort(links, offset);
		opHandler.removeRange(leftRange);

		Range rightRange = opHandler.addRange(offset + mitte, offset
				+ list.length);
		stepHandler.stepCompleted();
		rechts = mergesort(rechts, offset + mitte);
		opHandler.removeRange(rightRange);

		return merge(links, rechts, offset);
	}

	@Override
	public void run() {
		mergesort(elems, 0);
		algorithmEnd();
	}

}
