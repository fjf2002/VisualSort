package sortAlgorithms;

public class InsertionSort extends SortAlgorithm {

	@Override
	public void run() {
		opHandler.highlightRange(0, 1);
		for (int j = 1; j < elems.length; j++) {
			opHandler.setPointer("j", j);
			
			int key = elems[j];
			int i = j - 1;

			while (i >= 0 && elems[i] > key) {
				elems[i + 1] = elems[i];
				i = i - 1;
			}
			elems[i + 1] = key;

			opHandler.highlight(j, j);
			opHandler.shift(j, i + 1);
			opHandler.highlightOff();
			opHandler.highlightRange(0, j + 1);
			stepHandler.stepCompleted();
		}
		algorithmEnd();
	}

}
