package GUI;

public class Range {
	public int rangeBegin;
	public int rangeAfterEnd;

	public Range(int rangeBegin, int rangeAfterEnd) {
		this.rangeBegin = rangeBegin;
		this.rangeAfterEnd = rangeAfterEnd;
	}
}