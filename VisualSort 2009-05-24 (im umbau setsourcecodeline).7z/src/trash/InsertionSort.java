package trash;

import java.util.Arrays;

public class InsertionSort<T extends Comparable<T>> extends SortAlgorithm<T> {
	private int i;

	public InsertionSort(T[] elems) {
		super(elems);
		i = 0;
	}

	@Override
	public void smallStep() {
		if (sorted) {
			return;
		}
		T shiftElem = elems[i];
		int j = i;
		// shift elems to the right
		while (j != 0 && elems[j - 1].compareTo(shiftElem) > 0) {
			elems[j] = elems[j - 1];
			j--;
		}
		elems[j] = shiftElem;
		bigStepCompleted = true; // there are no small steps
		i++;
		if (i >= elems.length) {
			sorted = true;
		}
	}

	public static void main(String[] args) {
		Integer[] array = new Integer[] { 5, 1, 345, 2, 4, 3, 8 };

		InsertionSort<Integer> b = new InsertionSort<Integer>(array);
		while (!b.sorted) {
			b.smallStep();
			System.out.println(Arrays.toString(b.elems) + "\tbigSComp? "
					+ b.bigStepCompleted);
		}
	}
}
