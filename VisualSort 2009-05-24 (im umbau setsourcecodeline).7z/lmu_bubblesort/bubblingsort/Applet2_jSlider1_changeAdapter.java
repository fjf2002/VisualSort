/* Applet2_jSlider1_changeAdapter - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class Applet2_jSlider1_changeAdapter implements ChangeListener
{
    Applet2 adaptee;
    
    Applet2_jSlider1_changeAdapter(Applet2 applet2) {
	adaptee = applet2;
    }
    
    public void stateChanged(ChangeEvent changeevent) {
	adaptee.jSlider1_stateChanged(changeevent);
    }
}
