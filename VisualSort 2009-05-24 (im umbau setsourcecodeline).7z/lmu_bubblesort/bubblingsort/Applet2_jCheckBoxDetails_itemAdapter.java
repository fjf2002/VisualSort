/* Applet2_jCheckBoxDetails_itemAdapter - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package bubblingsort;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

class Applet2_jCheckBoxDetails_itemAdapter implements ItemListener
{
    Applet2 adaptee;
    
    Applet2_jCheckBoxDetails_itemAdapter(Applet2 applet2) {
	adaptee = applet2;
    }
    
    public void itemStateChanged(ItemEvent itemevent) {
	adaptee.jCheckBoxDetails_itemStateChanged(itemevent);
    }
}
